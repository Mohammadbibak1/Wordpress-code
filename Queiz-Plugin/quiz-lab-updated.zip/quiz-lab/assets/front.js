(function(){
  const wrap=document.querySelector('.ql-wrap'); if(!wrap||!window.QL) return;
  const quizId=parseInt(wrap.dataset.quizId,10);
  const titleEl=wrap.querySelector('.ql-title');
  const timerPill=wrap.querySelector('.ql-pill--timer');
  const timerEl=wrap.querySelector('.ql-timer');
  const stepEl=wrap.querySelector('.ql-step');
  const bodyEl=wrap.querySelector('.ql-body');
  const prevBtn=wrap.querySelector('.ql-prev');
  const nextBtn=wrap.querySelector('.ql-next');
  const finishBtn=wrap.querySelector('.ql-finish');
  const resultEl=wrap.querySelector('.ql-result');
  const progressBar=wrap.querySelector('.ql-progress-bar');

  let quiz=null,index=0,answers={},startTs=Date.now(),remaining=0,timerInt=null,attemptId=0,finishing=false;

  function api(url,opts={}){
    return fetch(url,{...opts,headers:{...(opts.headers||{}),'Content-Type':'application/json','X-WP-Nonce':QL.nonce},keepalive:true})
      .then(async r=>{let data={}; try{data=await r.json()}catch(e){} return {ok:r.ok,status:r.status,data};});
  }
  function fmtTime(sec){const m=Math.floor(sec/60),s=sec%60; return `${m}:${String(s).padStart(2,'0')}`;}
  function toast(msg){const t=document.createElement('div'); t.className='ql-toast'; t.textContent=msg; document.body.appendChild(t);
    setTimeout(()=>t.classList.add('ql-toast--show'),10);
    setTimeout(()=>{t.classList.remove('ql-toast--show'); setTimeout(()=>t.remove(),300)},2500);
  }
  function warnOnLeave(enable){
    if(!enable){window.onbeforeunload=null; return;}

  let historyTrapped=false;
  function trapHistory(enable){
    if(!enable){
      if(historyTrapped){
        window.removeEventListener('popstate', onPopState);
        historyTrapped=false;
      }
      return;
    }
    if(historyTrapped) return;
    historyTrapped=true;
    try{history.pushState({ql_quiz:quizId}, document.title, location.href);}catch(e){}
    window.addEventListener('popstate', onPopState);
  }
  function onPopState(e){
    if(finishing) return;
    toast(QL.strings.cant_leave_toast || QL.strings.confirm_leave);
    try{history.pushState({ql_quiz:quizId}, document.title, location.href);}catch(err){}
  }
    window.onbeforeunload=function(e){e.preventDefault(); e.returnValue=QL.strings.confirm_leave; return e.returnValue;};
  }
  function setProgress(){
    const total=quiz.questions.length||1;
    const p=Math.round(((index+1)/total)*100);
    progressBar.style.width=p+'%';
    stepEl.textContent=`سوال ${index+1} از ${total}`;
  }
  function mustAnswerCurrent(){return answers[index]===undefined||answers[index]===null||answers[index]<0;}
  async function abandonIfNeeded(){
    if(!attemptId||finishing) return;
    try{await api(`${QL.rest}/abandon`,{method:'POST',body:JSON.stringify({attempt_id:attemptId})});}catch(e){}
  }
  function renderQuestion(){
    const q=quiz.questions[index];
    titleEl.textContent=quiz.title||'';
    const htmlOpts=(q.options||[]).map((opt,oi)=>{
      const checked=(answers[index]===oi)?'checked':'';
      return `<label class="ql-opt" role="button" tabindex="0">
        <input type="radio" name="ql_opt" value="${oi}" ${checked}/>
        <span>${opt}</span>
      </label>`;
    }).join('');
    bodyEl.innerHTML=`<div class="ql-q"><div class="ql-q-title">${q.title||''}</div><div class="ql-opts">${htmlOpts}</div></div>`;
    bodyEl.querySelectorAll('input[name="ql_opt"]').forEach(r=>r.addEventListener('change',e=>{answers[index]=parseInt(e.target.value,10)}));
    bodyEl.querySelectorAll('.ql-opt').forEach(label=>{
      label.addEventListener('keydown',e=>{
        if(e.key==='Enter'||e.key===' '){e.preventDefault(); const inp=label.querySelector('input'); if(inp){inp.checked=true; inp.dispatchEvent(new Event('change',{bubbles:true}))}}
      });
    });
    prevBtn.disabled=index===0;
    const last=index===quiz.questions.length-1;
    nextBtn.style.display=last?'none':'inline-flex';
    finishBtn.style.display=last?'inline-flex':'none';
    setProgress();
  }
  function go(delta){const ni=index+delta; if(ni<0||ni>=quiz.questions.length) return; index=ni; renderQuestion();}
  async function startAttempt(){
    const res=await api(`${QL.rest}/start`,{method:'POST',body:JSON.stringify({quiz_id:quizId})});
    if(!res.ok) throw new Error(res.data.message||QL.strings.start_error);
    attemptId=parseInt(res.data.attempt_id,10)||0;
  }
  function startTimer(limit){
    if(!limit){timerPill.style.display='none'; return;}
    timerPill.style.display='inline-flex';
    remaining=limit;
    timerEl.textContent='⏳ '+fmtTime(remaining);
    timerInt=setInterval(()=>{remaining--; timerEl.textContent='⏳ '+fmtTime(Math.max(0,remaining));
      if(remaining<=0){clearInterval(timerInt); toast(QL.strings.time_over); doFinish();}
    },1000);
  }
  async function doFinish(){
    if(finishing) return;
    finishing=true;
    warnOnLeave(false);
    trapHistory(false);
    prevBtn.disabled=nextBtn.disabled=finishBtn.disabled=true;
    const timeSpent=Math.round((Date.now()-startTs)/1000);
    const res=await api(`${QL.rest}/finish`,{method:'POST',body:JSON.stringify({quiz_id:quizId,attempt_id:attemptId,answers,time_spent:timeSpent})});
    resultEl.style.display='block';
    if(!res.ok){
      resultEl.innerHTML=`<div class="ql-alert ql-alert--error">خطا: ${res.data.message||QL.strings.unknown_error}</div>`;
      finishing=false; warnOnLeave(true); prevBtn.disabled=nextBtn.disabled=finishBtn.disabled=false; return;
    }
    if(res.data.type==='normal'){
      resultEl.innerHTML=`<div class="ql-done"><h3>نتیجه آزمون</h3><div class="ql-score"><div class="ql-score__main">${res.data.percent}%</div><div class="ql-score__sub">امتیاز ${res.data.score} از ${res.data.max}</div></div></div>`;
    }else if(res.data.type==='poll'){
      const stats=res.data.poll_stats||[];
      const blocks=stats.map(s=>{
        const opts=(s.options||[]).map(o=>`<div class="ql-bar"><div class="ql-bar__top"><span>${o.label}</span><b>${o.percent}%</b></div><div class="ql-bar__track"><div class="ql-bar__fill" style="width:${o.percent}%;"></div></div></div>`).join('');
        return `<div class="ql-poll-q"><h4>${s.question}</h4><div class="ql-poll-opts">${opts}</div></div>`;
      }).join('');
      resultEl.innerHTML=`<div class="ql-done"><h3>نتیجه نظرسنجی</h3>${blocks}</div>`;
    }else{
      const type=res.data.personality_type||'-';
      const totals=res.data.totals||{};
      const top=Object.entries(totals).slice(0,4).map(([k,v])=>`<li><b>${k}</b><span>${v}</span></li>`).join('');
      resultEl.innerHTML=`<div class="ql-done"><h3>نتیجه شخصیت‌شناسی</h3><div class="ql-type-box"><div class="ql-type-box__label">تیپ غالب شما</div><div class="ql-type-box__value">${type}</div></div>${top?`<ul class="ql-toptypes">${top}</ul>`:''}${res.data.redirect_url?`<div class="ql-redirect">${QL.strings.redirecting}</div>`:''}</div>`;
      if(res.data.redirect_url){setTimeout(()=>{window.location.href=res.data.redirect_url},1200);}
    }
    wrap.querySelector('.ql-actions').style.display='none';
    bodyEl.style.display='none';
    if(timerInt) clearInterval(timerInt);
    window.onbeforeunload=null;
  }

  prevBtn.addEventListener('click',()=>go(-1));
  nextBtn.addEventListener('click',()=>{if(mustAnswerCurrent()) return toast(QL.strings.select_option); go(1);});
  finishBtn.addEventListener('click',()=>{if(mustAnswerCurrent()) return toast(QL.strings.select_option); doFinish();});

  window.addEventListener('pagehide',abandonIfNeeded);
  window.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden') abandonIfNeeded();});

  (async function init(){
    try{
      quiz=await fetch(`${QL.rest}/quiz/${quizId}`).then(r=>r.json());
      if(quiz.login_required && !QL.is_logged_in){
        bodyEl.innerHTML=`<div class="ql-alert ql-alert--error">${QL.strings.login_required}</div>`;
        wrap.querySelector('.ql-actions').style.display='none'; return;
      }
      await startAttempt();
      startTs=Date.now();
      warnOnLeave(true);
      trapHistory(true);
      startTimer(parseInt(quiz.time_limit||0,10));
      renderQuestion();
    }catch(e){
      bodyEl.innerHTML=`<div class="ql-alert ql-alert--error">${(e&&e.message)?e.message:QL.strings.unknown_error}</div>`;
      wrap.querySelector('.ql-actions').style.display='none';
    }
  })();
})();