<?php
/**
 * Plugin Name: Quiz Lab
 * Description: Advanced quiz builder with results and analytics (MVP).
 * Version: 1.0.0
 * Author: Quiz Lab
 * Text Domain: quiz-lab
 */

if (!defined('ABSPATH')) exit;

define('QL_VERSION', '1.0.0');
define('QL_PATH', plugin_dir_path(__FILE__));
define('QL_URL', plugin_dir_url(__FILE__));

require_once QL_PATH . 'includes/helpers.php';
require_once QL_PATH . 'includes/class-ql-db.php';
require_once QL_PATH . 'includes/class-ql-cpt.php';
require_once QL_PATH . 'includes/class-ql-admin.php';
require_once QL_PATH . 'includes/class-ql-engine.php';
require_once QL_PATH . 'includes/class-ql-rest.php';

final class Quiz_Lab_Plugin {
    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook(__FILE__, ['QL_DB', 'activate']);
        add_action('init', ['QL_CPT', 'register']);
        add_action('admin_menu', ['QL_Admin', 'menu']);
        add_action('add_meta_boxes', ['QL_Admin', 'metaboxes']);
        add_action('save_post_ql_quiz', ['QL_Admin', 'save_quiz_meta'], 10, 2);

        add_action('rest_api_init', ['QL_REST', 'routes']);

        add_shortcode('quiz_lab', ['QL_Admin', 'shortcode']);

        add_action('wp_enqueue_scripts', ['QL_Admin', 'enqueue_front_assets']);
        add_action('admin_enqueue_scripts', ['QL_Admin', 'enqueue_admin_assets']);
    }
}

Quiz_Lab_Plugin::instance();
