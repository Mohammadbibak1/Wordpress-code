<?php
if (!defined('ABSPATH')) exit;

class QL_Admin {

    public static function menu() {
        add_menu_page(
            'Quiz Lab',
            'Quiz Lab',
            'manage_options',
            'quiz-lab',
            [self::class, 'page_quizzes'],
            'dashicons-welcome-learn-more'
        );

        add_submenu_page(
            'quiz-lab',
            'Results',
            'Results',
            'manage_options',
            'quiz-lab-results',
            [self::class, 'page_results']
        );
    }

    public static function page_quizzes() {
        echo '<div class="wrap"><h1>Quiz Lab</h1>';
        echo '<p>برای مدیریت آزمون‌ها از منوی <b>Quiz Lab</b> و نوع پست <b>Quiz</b> استفاده کن.</p>';
        echo '<p><a class="button button-primary" href="' . admin_url('post-new.php?post_type=ql_quiz') . '">Add New Quiz</a></p>';
        echo '</div>';
    }

    public static function page_results() {
        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';

        $rows = $wpdb->get_results("SELECT * FROM $attempts ORDER BY id DESC LIMIT 50", ARRAY_A);

        echo '<div class="wrap"><h1>Quiz Results (Last 50)</h1>';
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>ID</th><th>Quiz</th><th>User</th><th>Score</th><th>Percent</th><th>Time</th><th>Date</th></tr></thead><tbody>';

        if (!$rows) {
            echo '<tr><td colspan="7">No results yet.</td></tr>';
        } else {
            foreach ($rows as $r) {
                $quiz_title = get_the_title((int)$r['quiz_id']);
                $user = (int)$r['user_id'] ? (get_userdata((int)$r['user_id'])->user_login ?? 'User') : 'Guest';
                echo '<tr>';
                echo '<td>' . (int)$r['id'] . '</td>';
                echo '<td>' . esc_html($quiz_title ?: ('#'.$r['quiz_id'])) . '</td>';
                echo '<td>' . esc_html($user) . '</td>';
                echo '<td>' . (int)$r['score'] . ' / ' . (int)$r['max_score'] . '</td>';
                echo '<td>' . (int)$r['percent'] . '%</td>';
                echo '<td>' . (int)$r['time_spent'] . 's</td>';
                echo '<td>' . esc_html($r['created_at']) . '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table></div>';
    }

    public static function ajax_pages() {
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'forbidden'], 403);
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'ql_admin')) wp_send_json_error(['message' => 'bad_nonce'], 403);
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'numberposts' => 200,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);
        $out = [];
        foreach ($pages as $p) {
            $out[] = ['id' => (int)$p->ID, 'title' => get_the_title($p->ID)];
        }
        wp_send_json_success(['pages' => $out]);
    }

    public static function metaboxes() {
        add_meta_box(
            'ql_quiz_settings',
            'Quiz Settings',
            [self::class, 'metabox_settings'],
            'ql_quiz',
            'normal',
            'high'
        );

        add_meta_box(
            'ql_quiz_questions',
            'Questions Builder',
            [self::class, 'metabox_questions'],
            'ql_quiz',
            'normal',
            'high'
        );
    }

    ($post) {
        $questions = get_post_meta($post->ID, '_ql_questions', true);
        $questions = is_array($questions) ? $questions : [];

        echo '<div id="ql-questions-builder" data-questions="' . esc_attr(wp_json_encode($questions)) . '"></div>';
        echo '<input type="hidden" id="ql_questions_input" name="ql_questions_json" value="' . esc_attr(wp_json_encode($questions)) . '" />';
        echo '<p style="color:#666;margin-top:8px;">سوال‌ها را بساز، گزینه درست را مشخص کن، سپس ذخیره کن.</p>';
    }

    public static function save_quiz_meta($post_id, $post) {
        if (!isset($_POST['ql_nonce']) || !wp_verify_nonce($_POST['ql_nonce'], 'ql_save_quiz')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $type = isset($_POST['ql_type']) ? sanitize_text_field($_POST['ql_type']) : 'normal';
        update_post_meta($post_id, '_ql_type', $type);

        $time_limit = isset($_POST['ql_time_limit']) ? (int)$_POST['ql_time_limit'] : 0;
        update_post_meta($post_id, '_ql_time_limit', max(0, $time_limit));

        $login_required = ql_sanitize_bool($_POST['ql_login_required'] ?? 0);
        update_post_meta($post_id, '_ql_login_required', $login_required);

        $raw = wp_unslash($_POST['ql_questions_json'] ?? '');
        $arr = json_decode($raw, true);
        if (!is_array($arr)) $arr = [];

        $clean = [];
        foreach ($arr as $q) {
            $title = isset($q['title']) ? sanitize_text_field($q['title']) : '';
            $options = isset($q['options']) && is_array($q['options']) ? array_map('sanitize_text_field', $q['options']) : [];
            $correct = isset($q['correct']) ? (int)$q['correct'] : -1;

            $clean[] = [
                'title' => $title,
                'options' => array_values($options),
                'correct' => $correct,
            ];
        }

        update_post_meta($post_id, '_ql_questions', $clean);
    }

    public static function shortcode($atts) {
        $atts = shortcode_atts(['id' => 0], $atts);
        $id = (int)$atts['id'];
        if (!$id) return '<div>Quiz id is required.</div>';

        ob_start();
        echo '<div class="ql-wrap" data-quiz-id="' . esc_attr($id) . '">
                <div class="ql-header">
                    <div class="ql-title"></div>
                    <div class="ql-timer"></div>
                </div>
                <div class="ql-progress"><div class="ql-progress-bar"></div></div>
                <div class="ql-body"></div>
                <div class="ql-actions">
                    <button class="ql-btn ql-prev" type="button">قبلی</button>
                    <button class="ql-btn ql-next" type="button">بعدی</button>
                    <button class="ql-btn ql-finish" type="button" style="display:none;">پایان آزمون</button>
                </div>
                <div class="ql-result" style="display:none;"></div>
              </div>';
        return ob_get_clean();
    }

    public static function enqueue_front_assets() {
        wp_register_style('quiz-lab-front', QL_URL . 'assets/front.css', [], QL_VERSION);
        wp_register_script('quiz-lab-front', QL_URL . 'assets/front.js', [], QL_VERSION, true);

        wp_enqueue_style('quiz-lab-front');
        wp_enqueue_script('quiz-lab-front');

        wp_localize_script('quiz-lab-front', 'QL', [
            'rest' => esc_url_raw(rest_url('quiz-lab/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }

    public static function enqueue_admin_assets($hook) {
        if ($hook !== 'post.php' && $hook !== 'post-new.php') return;
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== 'ql_quiz') return;

        wp_enqueue_style('quiz-lab-admin', QL_URL . 'assets/admin.css', [], QL_VERSION);
        wp_enqueue_script('quiz-lab-admin', QL_URL . 'assets/admin.js', [], QL_VERSION, true);
    }
}
