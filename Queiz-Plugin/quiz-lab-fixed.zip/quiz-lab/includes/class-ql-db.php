<?php
if (!defined('ABSPATH')) exit;

class QL_DB {
    public static function activate() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $attempts = $wpdb->prefix . 'ql_attempts';
        $answers  = $wpdb->prefix . 'ql_attempt_answers';

        $sql1 = "CREATE TABLE $attempts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            quiz_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'finished',
            score INT NOT NULL DEFAULT 0,
            max_score INT NOT NULL DEFAULT 0,
            percent INT NOT NULL DEFAULT 0,
            time_spent INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY quiz_id (quiz_id),
            KEY user_id (user_id),
            KEY status (status)
        ) %s;";

        $sql2 = "CREATE TABLE $answers (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            attempt_id BIGINT UNSIGNED NOT NULL,
            question_index INT NOT NULL,
            selected_option INT NOT NULL DEFAULT -1,
            is_correct TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY attempt_id (attempt_id)
        ) %s;";

        dbDelta(sprintf($sql1, $charset_collate));
        dbDelta(sprintf($sql2, $charset_collate));

        update_option('ql_version', QL_VERSION);
    }
}
