<?php
if (!defined('ABSPATH')) exit;

class QL_Engine {
    public static function grade_normal(array $questions, array $answers): array {
        $score = 0;
        $max = count($questions);
        $details = [];

        foreach ($questions as $i => $q) {
            $correct = isset($q['correct']) ? (int)$q['correct'] : -1;
            $selected = isset($answers[$i]) ? (int)$answers[$i] : -1;

            $is_correct = ($selected === $correct && $correct >= 0);
            if ($is_correct) $score++;

            $details[] = [
                'question_index' => $i,
                'selected' => $selected,
                'correct' => $correct,
                'is_correct' => $is_correct ? 1 : 0,
            ];
        }

        $percent = $max > 0 ? (int) round(($score / $max) * 100) : 0;

        return [
            'score' => $score,
            'max' => $max,
            'percent' => $percent,
            'details' => $details,
        ];
    }
}
