<?php
if (!defined('ABSPATH')) exit;

class QL_CPT {
    public static function register() {
        register_post_type('ql_quiz', [
            'labels' => [
                'name' => 'Quiz Lab',
                'singular_name' => 'Quiz',
                'add_new' => 'Add New Quiz',
                'add_new_item' => 'Add New Quiz',
                'edit_item' => 'Edit Quiz',
            ],
            'public' => false,
            'show_ui' => true,
            'menu_icon' => 'dashicons-welcome-learn-more',
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);

        register_taxonomy('ql_quiz_category', 'ql_quiz', [
            'labels' => [
                'name' => 'Quiz Categories',
                'singular_name' => 'Quiz Category',
            ],
            'public' => false,
            'show_ui' => true,
            'hierarchical' => true,
        ]);
    }
}
