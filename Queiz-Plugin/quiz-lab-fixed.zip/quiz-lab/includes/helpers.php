<?php
if (!defined('ABSPATH')) exit;

function ql_sanitize_bool($v): int {
    return !empty($v) ? 1 : 0;
}

function ql_get_quiz_meta(int $quiz_id): array {
    $type = get_post_meta($quiz_id, '_ql_type', true);
    if (!$type) $type = 'normal';

    $time_limit = (int) get_post_meta($quiz_id, '_ql_time_limit', true);
    $login_required = (int) get_post_meta($quiz_id, '_ql_login_required', true);

    $questions = get_post_meta($quiz_id, '_ql_questions', true);
    $questions = is_array($questions) ? $questions : [];

    return [
        'type' => $type,
        'time_limit' => max(0, $time_limit),
        'login_required' => (int)$login_required,
        'questions' => $questions,
    ];
}

function ql_user_id_or_zero(): int {
    return is_user_logged_in() ? (int)get_current_user_id() : 0;
}
