<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// In the commercial version we can add an option to wipe data.
// For now, we do not delete any data on uninstall to prevent accidental loss.
