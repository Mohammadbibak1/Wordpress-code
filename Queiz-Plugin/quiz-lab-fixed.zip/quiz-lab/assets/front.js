(function () {
  const wrap = document.querySelector(".ql-wrap");
  if (!wrap || !window.QL) return;

  const quizId = parseInt(wrap.dataset.quizId, 10);
  const titleEl = wrap.querySelector(".ql-title");
  const timerEl = wrap.querySelector(".ql-timer");
  const bodyEl = wrap.querySelector(".ql-body");
  const prevBtn = wrap.querySelector(".ql-prev");
  const nextBtn = wrap.querySelector(".ql-next");
  const finishBtn = wrap.querySelector(".ql-finish");
  const resultEl = wrap.querySelector(".ql-result");
  const progressBar = wrap.querySelector(".ql-progress-bar");

  let quiz = null;
  let index = 0;
  let answers = {}; // {0: optionIndex, 1: optionIndex}
  let startTs = Date.now();
  let remaining = 0;
  let timerInt = null;

  function api(url, opts = {}) {
    return fetch(url, {
      ...opts,
      headers: {
        ...(opts.headers || {}),
        "Content-Type": "application/json",
        "X-WP-Nonce": QL.nonce,
      },
    }).then(r => r.json().then(j => ({ ok: r.ok, status: r.status, data: j })));
  }

  function setProgress() {
    const total = quiz.questions.length || 1;
    const p = Math.round(((index + 1) / total) * 100);
    progressBar.style.width = p + "%";
  }

  function fmtTime(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  function startTimer(limit) {
    if (!limit) { timerEl.textContent = ""; return; }
    remaining = limit;
    timerEl.textContent = "⏳ " + fmtTime(remaining);

    timerInt = setInterval(() => {
      remaining--;
      timerEl.textContent = "⏳ " + fmtTime(Math.max(0, remaining));
      if (remaining <= 0) {
        clearInterval(timerInt);
        doFinish();
      }
    }, 1000);

    window.addEventListener("beforeunload", (e) => {
      e.preventDefault();
      e.returnValue = "اگر صفحه را ببندید آزمون لغو می‌شود.";
      return e.returnValue;
    });
  }

  function renderQuestion() {
    const q = quiz.questions[index];
    titleEl.textContent = quiz.title || "";

    const htmlOpts = q.options.map((opt, oi) => {
      const checked = (answers[index] === oi) ? "checked" : "";
      return `
        <label class="ql-opt">
          <input type="radio" name="ql_opt" value="${oi}" ${checked} />
          <span>${opt}</span>
        </label>
      `;
    }).join("");

    bodyEl.innerHTML = `
      <div class="ql-q">
        <div class="ql-q-title">${q.title || ""}</div>
        <div class="ql-opts">${htmlOpts}</div>
      </div>
    `;

    bodyEl.querySelectorAll('input[name="ql_opt"]').forEach(r => {
      r.addEventListener("change", (e) => {
        answers[index] = parseInt(e.target.value, 10);
      });
    });

    prevBtn.disabled = index === 0;
    const last = index === quiz.questions.length - 1;
    nextBtn.style.display = last ? "none" : "inline-block";
    finishBtn.style.display = last ? "inline-block" : "none";

    setProgress();
  }

  function go(delta) {
    const ni = index + delta;
    if (ni < 0 || ni >= quiz.questions.length) return;
    index = ni;
    renderQuestion();
  }

  async function doFinish() {
    prevBtn.disabled = true;
    nextBtn.disabled = true;
    finishBtn.disabled = true;

    const timeSpent = Math.round((Date.now() - startTs) / 1000);
    const res = await api(`${QL.rest}/finish`, {
      method: "POST",
      body: JSON.stringify({
        quiz_id: quizId,
        answers,
        time_spent: timeSpent
      })
    });

    if (!res.ok) {
      resultEl.style.display = "block";
      resultEl.innerHTML = `<div class="ql-error">خطا: ${res.data.message || "نامشخص"}</div>`;
      return;
    }

    resultEl.style.display = "block";
    resultEl.innerHTML = `
      <div class="ql-done">
        <h3>نتیجه آزمون</h3>
        <p>نمره: <b>${res.data.score}</b> از <b>${res.data.max}</b></p>
        <p>درصد: <b>${res.data.percent}%</b></p>
      </div>
    `;

    wrap.querySelector(".ql-actions").style.display = "none";
    bodyEl.style.display = "none";
    if (timerInt) clearInterval(timerInt);
    window.onbeforeunload = null;
  }

  prevBtn.addEventListener("click", () => go(-1));
  nextBtn.addEventListener("click", () => go(1));
  finishBtn.addEventListener("click", doFinish);

  (async function init() {
    const res = await fetch(`${QL.rest}/quiz/${quizId}`).then(r => r.json());
    quiz = res;

    if (quiz.login_required && !document.body.classList.contains("logged-in")) {
      bodyEl.innerHTML = `<div class="ql-error">برای شرکت در این آزمون باید وارد حساب شوید.</div>`;
      wrap.querySelector(".ql-actions").style.display = "none";
      return;
    }

    startTs = Date.now();
    startTimer(parseInt(quiz.time_limit || 0, 10));
    renderQuestion();
  })();
})();