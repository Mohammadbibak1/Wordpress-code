/* Quiz Lab Admin UI (Tags + Redirects Ajax) */
(function(){
  const typeSelect = document.getElementById('ql_type');
  const personalityBox = document.getElementById('ql-personality-settings');

  const hiddenTypes = document.getElementById('ql_personality_types');
  const typesList = document.getElementById('ql_types_list');
  const typesText = document.getElementById('ql_types_text');
  const typesAdd = document.getElementById('ql_types_add');

  const redirectsContainer = document.getElementById('ql_redirects_container');

  if (!hiddenTypes || !typesList || !typesText || !redirectsContainer) return;

  const parse = (raw) => String(raw||'')
    .split(',').map(s=>s.trim()).filter(Boolean)
    .map(s=>s.toUpperCase())
    .filter((v,i,a)=>a.indexOf(v)===i);

  let types = parse(hiddenTypes.value || typesList.dataset.initial || '');

  const getSelected = () => {
    try { return JSON.parse(redirectsContainer.dataset.selected || '{}'); }
    catch(e){ return {}; }
  };
  const setSelected = (obj) => redirectsContainer.dataset.selected = JSON.stringify(obj||{});

  const syncHidden = () => {
    hiddenTypes.value = types.join(', ');
  };

  const renderTags = () => {
    typesList.innerHTML = '';
    types.forEach(t=>{
      const chip = document.createElement('span');
      chip.className='ql-tag';
      chip.innerHTML = `<span>${t}</span>`;
      const x = document.createElement('button');
      x.type='button';
      x.textContent='×';
      x.addEventListener('click', ()=>{
        types = types.filter(v=>v!==t);
        syncHidden();
        renderTags();
        renderRedirects();
      });
      chip.appendChild(x);
      typesList.appendChild(chip);
    });
    syncHidden();
  };

  const addType = () => {
    const v = String(typesText.value||'').trim();
    if (!v) return;
    const up = v.toUpperCase();
    if (!types.includes(up)) types.push(up);
    typesText.value='';
    renderTags();
    renderRedirects();
  };

  typesAdd.addEventListener('click', addType);
  typesText.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter') { e.preventDefault(); addType(); }
  });

  const updateVisibility = () => {
    if (!typeSelect || !personalityBox) return;
    personalityBox.style.display = (typeSelect.value === 'personality') ? 'block' : 'none';
  };
  if (typeSelect) typeSelect.addEventListener('change', updateVisibility);
  updateVisibility();

  let pagesCache = null;
  async function fetchPages(){
    if (pagesCache) return pagesCache;
    if (!window.QLAdminCfg) return [];
    const fd = new FormData();
    fd.append('action','ql_pages');
    fd.append('nonce', window.QLAdminCfg.nonce);
    const res = await fetch(window.QLAdminCfg.ajax_url, { method:'POST', body: fd, credentials:'same-origin' });
    const data = await res.json();
    pagesCache = data && data.success ? (data.data.pages || []) : [];
    return pagesCache;
  }

  async function renderRedirects(){
    if (!types.length){
      redirectsContainer.className='ql-empty';
      redirectsContainer.innerHTML='Type ها را اضافه کن تا این بخش ساخته شود.';
      return;
    }
    const pages = await fetchPages();
    const selected = getSelected();

    redirectsContainer.className='ql-grid';
    redirectsContainer.style.gridTemplateColumns='repeat(3, minmax(0, 1fr))';
    redirectsContainer.innerHTML='';

    types.forEach(t=>{
      const wrap=document.createElement('div');
      wrap.className='ql-field';
      const lbl=document.createElement('label');
      lbl.innerHTML=`<b>${t}</b>`;
      const sel=document.createElement('select');
      sel.className='ql-control';
      sel.name=`ql_redirect_page[${t}]`;

      const opt0=document.createElement('option');
      opt0.value=''; opt0.textContent='— بدون ریدایرکت —';
      sel.appendChild(opt0);

      pages.forEach(p=>{
        const o=document.createElement('option');
        o.value=String(p.id);
        o.textContent=p.title || ('#'+p.id);
        sel.appendChild(o);
      });

      sel.value = selected[t] ? String(selected[t]) : '';
      sel.addEventListener('change', ()=>{
        const map=getSelected();
        if (sel.value) map[t]=parseInt(sel.value,10);
        else delete map[t];
        setSelected(map);
      });

      wrap.appendChild(lbl);
      wrap.appendChild(sel);
      redirectsContainer.appendChild(wrap);
    });
  }

  renderTags();
  renderRedirects();
})();