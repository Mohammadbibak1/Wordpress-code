<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

global $wpdb;

$attempts = $wpdb->prefix . 'ql_attempts';
$answers  = $wpdb->prefix . 'ql_attempt_answers';

// Drop plugin tables
$wpdb->query("DROP TABLE IF EXISTS $answers");
$wpdb->query("DROP TABLE IF EXISTS $attempts");

// Delete plugin options
delete_option('ql_version');
delete_option('ql_font_css_url');
delete_option('ql_font_family');

// If you add more options in future, delete them here.
