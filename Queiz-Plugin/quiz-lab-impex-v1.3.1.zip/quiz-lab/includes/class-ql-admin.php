<?php
if (!defined('ABSPATH')) exit;

class QL_Admin {
        public static function menu() {
        add_menu_page('Quiz Lab', 'Quiz Lab', 'manage_options', 'quiz-lab', [self::class, 'page_home'], 'dashicons-welcome-learn-more', 26);
        add_submenu_page('quiz-lab', 'آزمون‌ها', 'آزمون‌ها', 'manage_options', 'edit.php?post_type=ql_quiz');
        add_submenu_page('quiz-lab', 'دسته‌بندی‌ها', 'دسته‌بندی‌ها', 'manage_options', 'edit-tags.php?taxonomy=ql_quiz_category&post_type=ql_quiz');
        add_submenu_page('quiz-lab', 'نتایج', 'نتایج', 'manage_options', 'quiz-lab-results', [self::class, 'page_results']);

        // AJAX: لیست برگه‌ها برای ریدایرکت‌ها
        add_action('wp_ajax_ql_pages', [self::class, 'ajax_pages']);

        // Import / Export (admin-post)
        add_action('admin_post_ql_export_questions', [self::class, 'handle_export_questions']);
        add_action('admin_post_ql_import_questions', [self::class, 'handle_import_questions']);
    }


    public static function page_home() {
        echo '<div class="wrap ql-admin-page">';
        echo '<h1>Quiz Lab</h1>';
        echo '<div class="ql-admin-hero">';
        echo '<div class="ql-admin-hero__text">';
        echo '<p style="margin:0 0 8px;">آزمون بساز، شورتکد بگیر، توی برگه بذار و نتایج رو ببین.</p>';
        echo '<p style="margin:0;color:#667085;">پشتیبانی: آزمون عادی، نظرسنجی (Poll)، شخصیت‌شناسی/MBTI</p>';
        echo '</div>';
        echo '<div class="ql-admin-hero__actions">';
        echo '<a class="button button-primary" href="' . admin_url('post-new.php?post_type=ql_quiz') . '">افزودن آزمون جدید</a> ';
        echo '<a class="button" href="' . admin_url('edit.php?post_type=ql_quiz') . '">مدیریت آزمون‌ها</a> ';
        echo '<a class="button" href="' . admin_url('admin.php?page=quiz-lab-results') . '">دیدن نتایج</a>';
        echo '</div></div>';
        echo '<div style="margin-top:14px" class="ql-admin-card">';
        echo '<b>شورتکد:</b> <code>[quiz_lab id="123"]</code> (عدد 123 را با ID آزمون جایگزین کن)';
        echo '</div>';
        echo '</div>';
    }

    public static function page_results() {
        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';
        $rows = $wpdb->get_results("SELECT * FROM $attempts ORDER BY id DESC LIMIT 150", ARRAY_A);

        echo '<div class="wrap ql-admin-page"><h1>نتایج (۱۵۰ مورد آخر)</h1>';
        echo '<table class="widefat striped ql-results-table">';
        echo '<thead><tr>
                <th>ID</th><th>آزمون</th><th>کاربر</th><th>نوع</th><th>وضعیت</th><th>نتیجه</th><th>زمان</th><th>تاریخ</th>
              </tr></thead><tbody>';

        if (!$rows) {
            echo '<tr><td colspan="8">هنوز نتیجه‌ای ثبت نشده.</td></tr>';
        } else {
            foreach ($rows as $r) {
                $quiz_id = (int)$r['quiz_id'];
                $quiz_title = get_the_title($quiz_id);
                $meta = ql_get_quiz_meta($quiz_id);
                $type = $meta['type'] ?? 'normal';

                $user = 'مهمان';
                if ((int)$r['user_id']) {
                    $u = get_userdata((int)$r['user_id']);
                    $user = $u ? $u->user_login : 'کاربر';
                }

                $type_map = ['normal' => 'عادی', 'poll' => 'نظرسنجی', 'personality' => 'شخصیت‌شناسی'];
                $type_fa = $type_map[$type] ?? $type;

                $status_map = ['started' => 'در حال انجام', 'finished' => 'تکمیل شده', 'abandoned' => 'لغو/بسته شده'];
                $status = $status_map[$r['status']] ?? $r['status'];

                if ($type === 'normal') $result = (int)$r['score'] . ' / ' . (int)$r['max_score'] . ' (' . (int)$r['percent'] . '%)';
                elseif ($type === 'poll') $result = 'ثبت شد';
                else $result = 'Type: ' . ($r['personality_type'] ? esc_html($r['personality_type']) : '-');

                echo '<tr>';
                echo '<td>' . (int)$r['id'] . '</td>';
                echo '<td>' . esc_html($quiz_title ?: ('#'.$quiz_id)) . '</td>';
                echo '<td>' . esc_html($user) . '</td>';
                echo '<td>' . esc_html($type_fa) . '</td>';
                echo '<td><span class="ql-badge ql-badge--' . esc_attr($r['status']) . '">' . esc_html($status) . '</span></td>';
                echo '<td>' . $result . '</td>';
                echo '<td>' . (int)$r['time_spent'] . ' ثانیه</td>';
                echo '<td>' . esc_html($r['created_at']) . '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table></div>';
    }

    
    public static function ajax_pages() {
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'forbidden'], 403);
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'ql_admin')) wp_send_json_error(['message' => 'bad_nonce'], 403);

        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'numberposts' => 200,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        $out = [];
        foreach ($pages as $p) {
            $out[] = ['id' => (int)$p->ID, 'title' => get_the_title($p->ID)];
        }
        wp_send_json_success(['pages' => $out]);
    }


    public static function metaboxes() {
        add_meta_box('ql_quiz_settings', 'تنظیمات آزمون', [self::class, 'metabox_settings'], 'ql_quiz', 'normal', 'high');
        add_meta_box('ql_quiz_questions', 'سوالات آزمون', [self::class, 'metabox_questions'], 'ql_quiz', 'normal', 'high');
        add_meta_box('ql_quiz_shortcode', 'شورتکد', [self::class, 'metabox_shortcode'], 'ql_quiz', 'side', 'high');
        add_meta_box('ql_quiz_impex', 'درون‌ریزی / برون‌ریزی', [self::class, 'metabox_impex'], 'ql_quiz', 'side', 'high');
    }




    public static function metabox_shortcode($post) {
        echo '<p>این شورتکد را در برگه/نوشته قرار بده:</p>';
        echo '<p><code style="font-size:12px;">[quiz_lab id="' . (int)$post->ID . '"]</code></p>';
    }


    
    public static function metabox_impex($post) {
        if (!current_user_can('edit_post', $post->ID)) return;

        $export_csv = wp_nonce_url(admin_url('admin-post.php?action=ql_export_questions&format=csv&quiz_id=' . (int)$post->ID), 'ql_impex_' . $post->ID);
        $export_json = wp_nonce_url(admin_url('admin-post.php?action=ql_export_questions&format=json&quiz_id=' . (int)$post->ID), 'ql_impex_' . $post->ID);

        echo '<p style="margin:0 0 8px">سوالات این آزمون را خروجی بگیر یا از فایل وارد کن.</p>';
        echo '<p style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 10px">';
        echo '<a class="button button-secondary" href="' . esc_url($export_csv) . '">Export CSV</a>';
        echo '<a class="button button-secondary" href="' . esc_url($export_json) . '">Export JSON</a>';
        echo '</p>';

        // Notice after import
        if (isset($_GET['ql_impex'])) {
            $msg = sanitize_text_field((string)$_GET['ql_impex']);
            if ($msg === 'success') {
                $count = isset($_GET['ql_count']) ? (int)$_GET['ql_count'] : 0;
                echo '<div class="notice notice-success inline" style="margin:0 0 10px"><p>✅ ' . esc_html($count) . ' سوال وارد شد.</p></div>';
            } elseif ($msg === 'error') {
                $err = isset($_GET['ql_err']) ? sanitize_text_field((string)$_GET['ql_err']) : 'خطا در ورود فایل';
                echo '<div class="notice notice-error inline" style="margin:0 0 10px"><p>❌ ' . esc_html($err) . '</p></div>';
            }
        }

        echo '<hr style="margin:10px 0" />';
        echo '<p style="margin:0 0 6px"><b>Import</b></p>';

        echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="ql_import_questions" />';
        echo '<input type="hidden" name="quiz_id" value="' . (int)$post->ID . '" />';
        wp_nonce_field('ql_impex_' . $post->ID);

        echo '<input type="file" name="ql_file" accept=".csv,.json" style="width:100%;margin:0 0 8px" />';
        echo '<div style="margin:0 0 8px">';
        echo '<label style="display:block;margin:0 0 6px">یا محتوای CSV/JSON را اینجا Paste کن (آپلود اختیاری):</label>';
        echo '<textarea name="ql_raw_import" rows="8" style="width:100%;margin:0" placeholder="JSON با { شروع می‌شود یا CSV با سطر عنوان (title,option_1,...)"></textarea>';
        echo '</div>';
        echo '<label style="display:block;margin:0 0 6px">حالت:</label>';
        echo '<select name="mode" style="width:100%;margin:0 0 8px">';
        echo '<option value="replace">جایگزین (پاک کردن سوالات قبلی)</option>';
        echo '<option value="append">اضافه کردن به سوالات موجود</option>';
        echo '</select>';

        echo '<button type="submit" class="button button-primary" style="width:100%">Import</button>';
        echo '</form>';

        echo '<p style="margin:10px 0 0; font-size:12px; opacity:.9">';
        echo 'CSV مناسب ویرایش با Excel است. JSON دقیقاً ساختار افزونه را نگه می‌دارد.';
        echo '</p>';
    }

    private static function impex_redirect_back($quiz_id, $args = []) {
        $url = add_query_arg($args, get_edit_post_link($quiz_id, 'url'));
        wp_safe_redirect($url);
        exit;
    }

    public static function handle_export_questions() {
        $quiz_id = isset($_GET['quiz_id']) ? (int)$_GET['quiz_id'] : 0;
        $format = isset($_GET['format']) ? sanitize_text_field((string)$_GET['format']) : 'csv';

        if (!$quiz_id || !current_user_can('edit_post', $quiz_id)) wp_die('Access denied');
        check_admin_referer('ql_impex_' . $quiz_id);

        $type = get_post_meta($quiz_id, '_ql_type', true) ?: 'normal';
        $questions = get_post_meta($quiz_id, '_ql_questions', true);
        $questions = is_array($questions) ? $questions : [];

        if ($format === 'json') {
            $filename = 'quiz-' . $quiz_id . '-questions.json';
            nocache_headers();
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $filename);
            echo wp_json_encode([
                'quiz_id' => $quiz_id,
                'type' => $type,
                'exported_at' => current_time('mysql'),
                'questions' => $questions
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        // CSV
        $max_opts = 8;
        $headers = ['title'];
        for ($i=1;$i<=$max_opts;$i++) $headers[] = 'option_' . $i;
        if ($type === 'personality') {
            for ($i=1;$i<=$max_opts;$i++) $headers[] = 'scores_' . $i; // JSON per option
            $headers[] = 'note';
        } else {
            $headers[] = 'correct_option'; // 1-based, empty for poll
        }

        $out = fopen('php://output', 'w');
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=quiz-' . $quiz_id . '-questions.csv');
        // BOM for Excel
        echo "ï»¿";

        fputcsv($out, $headers);

        foreach ($questions as $q) {
            $row = array_fill(0, count($headers), '');
            $row[0] = (string)($q['title'] ?? '');
            $opts = $q['options'] ?? [];
            if (!is_array($opts)) $opts = [];

            if ($type === 'personality') {
                for ($i=0;$i<min($max_opts,count($opts));$i++) {
                    $opt = $opts[$i];
                    $label = is_array($opt) ? (string)($opt['label'] ?? '') : (string)$opt;
                    $scores = is_array($opt) ? ($opt['scores'] ?? []) : [];
                    $row[1+$i] = $label;
                    $row[1+$max_opts+$i] = $scores ? wp_json_encode($scores, JSON_UNESCAPED_UNICODE) : '';
                }
                $row[1+$max_opts*2] = 'برای هر گزینه، scores را به صورت JSON مثل {"I":1,"E":0} بنویس. کلیدها باید با تایپ‌های شخصیت در تنظیمات آزمون یکی باشد.';
            } else {
                for ($i=0;$i<min($max_opts,count($opts));$i++) $row[1+$i] = (string)$opts[$i];
                $correct = isset($q['correct']) ? (int)$q['correct'] : -1;
                $row[1+$max_opts] = ($type === 'normal' && $correct >= 0) ? (string)($correct + 1) : '';
            }

            fputcsv($out, $row);
        }

        fclose($out);
        exit;
    }

    public static function handle_import_questions() {
        $quiz_id = isset($_POST['quiz_id']) ? (int)$_POST['quiz_id'] : 0;
        if (!$quiz_id || !current_user_can('edit_post', $quiz_id)) wp_die('Access denied');

        check_admin_referer('ql_impex_' . $quiz_id);

        $raw_import = isset($_POST['ql_raw_import']) ? trim((string) wp_unslash($_POST['ql_raw_import'])) : '';
        $has_file = !empty($_FILES['ql_file']) && isset($_FILES['ql_file']['tmp_name']) && is_uploaded_file($_FILES['ql_file']['tmp_name']);

        if (!$has_file && $raw_import === '') {
            self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'فایل یا متن برای ورود پیدا نشد']);
        }

        $mode = isset($_POST['mode']) ? sanitize_text_field((string)$_POST['mode']) : 'replace';
        $mode = in_array($mode, ['replace','append'], true) ? $mode : 'replace';

        $ext = '';
        $name = '';
        $tmp = '';
        if ($has_file) {
            $file = $_FILES['ql_file'];
            $name = (string)($file['name'] ?? '');
            $tmp  = $file['tmp_name'];
            $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        } else {
            // Determine from pasted content
            $first = ltrim($raw_import);
            $ext = (strlen($first) && ($first[0] === '{' || $first[0] === '[')) ? 'json' : 'csv';
        }

        $type = get_post_meta($quiz_id, '_ql_type', true) ?: 'normal';
        $types_raw = (string)get_post_meta($quiz_id, '_ql_personality_types', true);
        $allowed_types = ql_parse_types($types_raw);

        $existing = get_post_meta($quiz_id, '_ql_questions', true);
        $existing = is_array($existing) ? $existing : [];

        $imported = [];

        if ($ext === 'json') {
            $raw = $has_file ? file_get_contents($tmp) : $raw_import;
            $data = json_decode($raw, true);

            if (isset($data['questions'])) $data = $data['questions'];
            if (!is_array($data)) self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'JSON نامعتبر است']);

            $imported = self::sanitize_questions_array($data, $type, $allowed_types);

        } elseif ($ext === 'csv') {
            $fh = $has_file ? fopen($tmp, 'r') : fopen('php://temp', 'r+');
            if (!$has_file) { fwrite($fh, $raw_import); rewind($fh); }
            if (!$fh) self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'خواندن فایل ممکن نیست']);

            // read header (support comma/semicolon + Excel)
            @ini_set('auto_detect_line_endings', '1');
            $firstLine = fgets($fh);
            if ($firstLine === false) self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'CSV نامعتبر است']);
            $firstLine = trim($firstLine);
            $delim = (substr_count($firstLine, ';') > substr_count($firstLine, ',')) ? ';' : ',';
            $header = str_getcsv($firstLine, $delim);
            if (!$header || !is_array($header)) self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'CSV نامعتبر است']);

            // Normalize header
            $map = [];
            foreach ($header as $idx => $col) {
                $col = strtolower(trim((string)$col));
                $map[$col] = $idx;
            }

            $max_opts = 8;
            while (($row = fgetcsv($fh, 0, $delim)) !== false) {
                if (!is_array($row)) continue;
                $title = '';
                if (isset($map['title']) && isset($row[$map['title']])) $title = sanitize_text_field(wp_unslash((string)$row[$map['title']]));
                $title = trim($title);
                if (!$title) continue;

                $options = [];
                if ($type === 'personality') {
                    for ($i=1;$i<=$max_opts;$i++) {
                        $label_key = 'option_' . $i;
                        $score_key = 'scores_' . $i;

                        $label = isset($map[$label_key], $row[$map[$label_key]]) ? sanitize_text_field(wp_unslash((string)$row[$map[$label_key]])) : '';
                        $label = trim($label);
                        if ($label === '') continue;

                        $scores = [];
                        if (isset($map[$score_key], $row[$map[$score_key]])) {
                            $scores_raw = trim(wp_unslash((string)$row[$map[$score_key]]));
                            if ($scores_raw !== '') {
                                $decoded = json_decode($scores_raw, true);
                                if (is_array($decoded)) {
                                    foreach ($decoded as $k => $v) {
                                        $k = sanitize_text_field((string)$k);
                                        if (!in_array($k, $allowed_types, true)) continue;
                                        $scores[$k] = (int)$v;
                                    }
                                }
                            }
                        }
                        $options[] = ['label' => $label, 'scores' => $scores];
                    }
                    if (count($options) < 2) continue;
                    $imported[] = ['title' => $title, 'options' => $options, 'correct' => -1];
                } else {
                    for ($i=1;$i<=$max_opts;$i++) {
                        $label_key = 'option_' . $i;
                        $label = isset($map[$label_key], $row[$map[$label_key]]) ? sanitize_text_field(wp_unslash((string)$row[$map[$label_key]])) : '';
                        $label = trim($label);
                        if ($label !== '') $options[] = $label;
                    }
                    if (count($options) < 2) continue;

                    $correct = -1;
                    if ($type === 'normal') {
                        $c = '';
                        if (isset($map['correct_option'], $row[$map['correct_option']])) $c = trim((string)$row[$map['correct_option']]);
                        if ($c !== '' && is_numeric($c)) {
                            $correct = max(-1, (int)$c - 1);
                            if ($correct >= count($options)) $correct = -1;
                        }
                    }

                    $imported[] = ['title' => $title, 'options' => $options, 'correct' => ($type === 'normal') ? $correct : -1];
                }
            }
            fclose($fh);
        } else {
            self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'فقط CSV یا JSON قابل قبول است']);
        }

        if (!$imported) self::impex_redirect_back($quiz_id, ['ql_impex' => 'error', 'ql_err' => 'هیچ سوال معتبری پیدا نشد']);

        $final = ($mode === 'append') ? array_values(array_merge($existing, $imported)) : $imported;

        update_post_meta($quiz_id, '_ql_questions', $final);

        self::impex_redirect_back($quiz_id, ['ql_impex' => 'success', 'ql_count' => count($imported)]);
    }

    private static function sanitize_questions_array($arr, $type, $allowed_types) {
        $clean = [];
        if (!is_array($arr)) return $clean;

        $allowed_types = is_array($allowed_types) ? $allowed_types : [];

        foreach ($arr as $q) {
            if (!is_array($q)) continue;
            $title = sanitize_text_field((string)($q['title'] ?? ''));
            $title = trim($title);
            if (!$title) continue;

            $options = $q['options'] ?? [];
            $options = is_array($options) ? $options : [];

            if ($type === 'personality') {
                $objs = [];
                foreach ($options as $opt) {
                    $label = '';
                    $scores2 = [];
                    if (is_array($opt)) {
                        $label = sanitize_text_field((string)($opt['label'] ?? ''));
                        $scores = isset($opt['scores']) && is_array($opt['scores']) ? $opt['scores'] : [];
                        foreach ($scores as $k => $v) {
                            $k = sanitize_text_field((string)$k);
                            if (!in_array($k, $allowed_types, true)) continue;
                            $scores2[$k] = (int)$v;
                        }
                    } else {
                        $label = sanitize_text_field((string)$opt);
                    }
                    $label = trim($label);
                    if ($label === '') continue;
                    $objs[] = ['label' => $label, 'scores' => $scores2];
                }
                if (count($objs) < 2) continue;
                $clean[] = ['title' => $title, 'options' => $objs, 'correct' => -1];
            } else {
                $opts = [];
                foreach ($options as $opt) {
                    $label = is_array($opt) ? (string)($opt['label'] ?? '') : (string)$opt;
                    $label = trim(sanitize_text_field($label));
                    if ($label !== '') $opts[] = $label;
                }
                if (count($opts) < 2) continue;

                $correct = isset($q['correct']) ? (int)$q['correct'] : -1;
                if ($type !== 'normal') $correct = -1;
                if ($correct >= count($opts)) $correct = -1;

                $clean[] = ['title' => $title, 'options' => $opts, 'correct' => ($type === 'normal') ? $correct : -1];
            }
        }

        return $clean;
    }


    public static function metabox_settings($post) {
        $type = get_post_meta($post->ID, '_ql_type', true) ?: 'normal';
        $time_limit = (int) get_post_meta($post->ID, '_ql_time_limit', true);
        $login_required = (int) get_post_meta($post->ID, '_ql_login_required', true);

        $types_raw = (string)get_post_meta($post->ID, '_ql_personality_types', true);
        $redirects = get_post_meta($post->ID, '_ql_personality_redirects', true);
        $redirects = is_array($redirects) ? $redirects : [];

        wp_nonce_field('ql_save_quiz', 'ql_nonce');

        echo '<div class="ql-admin-card"><div class="ql-grid">';
        echo '<div class="ql-field"><label><b>نوع آزمون</b></label>
              <select class="ql-control" name="ql_type" id="ql_type">
                <option value="normal" ' . selected($type, 'normal', false) . '>آزمون عادی (درست/غلط)</option>
                <option value="poll" ' . selected($type, 'poll', false) . '>نظرسنجی (Poll)</option>
                <option value="personality" ' . selected($type, 'personality', false) . '>شخصیت‌شناسی/MBTI</option>
              </select>
              <small>نوع آزمون روی سازنده سوالات اثر دارد.</small></div>';

        echo '<div class="ql-field"><label><b>تایمر (ثانیه)</b></label>
              <input class="ql-control" type="number" name="ql_time_limit" value="' . esc_attr($time_limit) . '" min="0" />
              <small>۰ یعنی بدون تایمر.</small></div>';

        echo '<div class="ql-field"><label><b>دسترسی</b></label>
              <label class="ql-check"><input type="checkbox" name="ql_login_required" value="1" ' . checked($login_required, 1, false) . ' /> فقط کاربران لاگین‌شده</label>
              <small>اگر فعال باشد، مهمان‌ها نمی‌توانند آزمون را شروع کنند.</small></div>';
        echo '</div></div>';

        echo '<div class="ql-admin-card" style="margin-top:12px;" id="ql-personality-settings">';
        echo '<h3 style="margin:0 0 10px;">تنظیمات شخصیت‌شناسی/MBTI</h3>';
        echo '<div class="ql-field"><label><b>لیست Type ها</b></label>
              <div class="ql-tag-input">
                <input class="ql-control" type="text" id="ql_types_text" placeholder="Type را بنویس و Enter بزن… (مثلاً INTJ)" />
                <button type="button" class="button" id="ql_types_add">افزودن</button>
              </div>
              <div id="ql_types_list" class="ql-tags" data-initial="' . esc_attr($types_raw) . '"></div>
              <input type="hidden" name="ql_personality_types" id="ql_personality_types" value="' . esc_attr($types_raw) . '" />
              <small>مثل انتخاب «کلمه کلیدی»: تایپ کن و Enter بزن؛ لیست پایین اضافه می‌شود.</small></div>';

        $types = ql_parse_types($types_raw);
        if (!empty($types)) {
            echo '<div class="ql-field" style="margin-top:10px;"><label><b>ریدایرکت نتیجه</b></label>
                  <small>برای هر Type یک برگه انتخاب کن (یا خالی بذار).</small></div>';
            echo '<div class="ql-grid" style="grid-template-columns: repeat(3, minmax(0, 1fr));">';
            foreach ($types as $t) {
                $selected_page = $redirects[$t] ?? '';
                echo '<div class="ql-field"><label><b>' . esc_html($t) . '</b></label>';
                wp_dropdown_pages([
                    'name' => 'ql_redirect_page[' . esc_attr($t) . ']',
                    'show_option_none' => '— بدون ریدایرکت —',
                    'option_none_value' => '',
                    'selected' => is_numeric($selected_page) ? (int)$selected_page : 0,
                ]);
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<div class="ql-empty" style="margin-top:10px;">برای ریدایرکت، اول Type ها را وارد کن و ذخیره کن.</div>';
        }

        echo '</div>';
    }

    public static function metabox_questions($post) {
        $questions = get_post_meta($post->ID, '_ql_questions', true);
        $questions = is_array($questions) ? $questions : [];
        $meta = ql_get_quiz_meta($post->ID);

        echo '<div id="ql-questions-builder" class="ql-builder"
              data-type="' . esc_attr($meta['type'] ?? 'normal') . '"
              data-types="' . esc_attr(wp_json_encode($meta['personality_types'] ?? [])) . '"
              data-questions="' . esc_attr(wp_json_encode($questions)) . '"></div>';

        echo '<input type="hidden" id="ql_questions_input" name="ql_questions_json" value="' . esc_attr(wp_json_encode($questions)) . '" />';
    }

    public static function save_quiz_meta($post_id, $post) {
        if (!isset($_POST['ql_nonce']) || !wp_verify_nonce($_POST['ql_nonce'], 'ql_save_quiz')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $type = isset($_POST['ql_type']) ? sanitize_text_field($_POST['ql_type']) : 'normal';
        update_post_meta($post_id, '_ql_type', $type);

        $time_limit = isset($_POST['ql_time_limit']) ? (int)$_POST['ql_time_limit'] : 0;
        update_post_meta($post_id, '_ql_time_limit', max(0, $time_limit));

        $login_required = ql_sanitize_bool($_POST['ql_login_required'] ?? 0);
        update_post_meta($post_id, '_ql_login_required', $login_required);

        $types_raw = isset($_POST['ql_personality_types']) ? sanitize_text_field($_POST['ql_personality_types']) : '';
        update_post_meta($post_id, '_ql_personality_types', $types_raw);

        $redirect_pages = [];
        if (isset($_POST['ql_redirect_page']) && is_array($_POST['ql_redirect_page'])) {
            foreach ($_POST['ql_redirect_page'] as $t => $pid) {
                $t = sanitize_text_field($t);
                $pid = (int)$pid;
                if ($pid > 0) $redirect_pages[$t] = $pid;
            }
        }
        update_post_meta($post_id, '_ql_personality_redirects', $redirect_pages);

        $raw = wp_unslash($_POST['ql_questions_json'] ?? '');
        $arr = json_decode($raw, true);
        if (!is_array($arr)) $arr = [];

        $types = ql_parse_types($types_raw);

        $clean = [];
        foreach ($arr as $q) {
            $title = isset($q['title']) ? sanitize_text_field($q['title']) : '';
            if (!$title) continue;

            $options = isset($q['options']) && is_array($q['options']) ? $q['options'] : [];
            $correct = isset($q['correct']) ? (int)$q['correct'] : -1;

            if ($type === 'personality') {
                $objs = [];
                foreach ($options as $opt) {
                    $label = '';
                    $scores2 = [];
                    if (is_array($opt)) {
                        $label = sanitize_text_field($opt['label'] ?? '');
                        $scores = isset($opt['scores']) && is_array($opt['scores']) ? $opt['scores'] : [];
                        foreach ($scores as $k => $v) {
                            $k = sanitize_text_field((string)$k);
                            if (!in_array($k, $types, true)) continue;
                            $scores2[$k] = (int)$v;
                        }
                    } else {
                        $label = sanitize_text_field((string)$opt);
                    }
                    $label = trim($label);
                    if (!$label) continue;
                    $objs[] = ['label' => $label, 'scores' => $scores2];
                }
                if (count($objs) < 2) continue;
                $clean[] = ['title' => $title, 'options' => $objs, 'correct' => -1];
            } else {
                $opts = [];
                foreach ($options as $opt) {
                    $label = is_array($opt) ? (string)($opt['label'] ?? '') : (string)$opt;
                    $label = trim(sanitize_text_field($label));
                    if ($label !== '') $opts[] = $label;
                }
                if (count($opts) < 2) continue;
                $clean[] = ['title' => $title, 'options' => $opts, 'correct' => ($type === 'normal') ? $correct : -1];
            }
        }

        update_post_meta($post_id, '_ql_questions', $clean);
    }

    public static function shortcode($atts) {
        // اطمینان از لود شدن فایل‌های فرانت حتی در المنتور/صفحه‌سازها
        wp_enqueue_style('quiz-lab-front');
        wp_enqueue_script('quiz-lab-front');
        $atts = shortcode_atts(['id' => 0], $atts);
        $id = (int)$atts['id'];
        if (!$id) return '<div class="ql-alert ql-alert--error">شناسه آزمون مشخص نیست.</div>';

        return '<div class="ql-wrap" data-quiz-id="' . esc_attr($id) . '">
            <div class="ql-card">
              <div class="ql-top">
                <div class="ql-title"></div>
                <div class="ql-meta">
                  <div class="ql-pill ql-pill--timer" style="display:none;"><span class="ql-timer"></span></div>
                  <div class="ql-pill ql-pill--step"><span class="ql-step"></span></div>
                </div>
              </div>
              <div class="ql-progress"><div class="ql-progress-bar"></div></div>
              <div class="ql-body"></div>
              <div class="ql-actions">
                <button class="ql-btn ql-btn--ghost ql-prev" type="button">قبلی</button>
                <button class="ql-btn ql-next" type="button">بعدی</button>
                <button class="ql-btn ql-finish" type="button" style="display:none;">ثبت و پایان</button>
              </div>
              <div class="ql-result" style="display:none;"></div>
            </div>
          </div>';
    }

    public static function enqueue_front_assets() {
        // ثبت فایل‌ها (در هر حال)
        wp_register_style('quiz-lab-front', QL_URL . 'assets/front.css', [], QL_VERSION);
        wp_register_script('quiz-lab-front', QL_URL . 'assets/front.js', [], QL_VERSION, true);

        // اگر در صفحه تکی هستیم، به صورت هوشمند لود کن؛
        // وگرنه هنگام اجرای شورتکد در shortcode() هم enqueue می‌شود.
        if (!is_singular()) return;

        $post = get_post();
        if (!$post) return;

        // برای سازگاری با صفحه‌سازها: فقط به محتوای اصلی اکتفا نکن
        $has = has_shortcode($post->post_content ?? '', 'quiz_lab');
        if (!$has && stripos($post->post_content ?? '', '[quiz_lab') === false) return;

        wp_enqueue_style('quiz-lab-front');
        wp_enqueue_script('quiz-lab-front');

        wp_localize_script('quiz-lab-front', 'QL', [
            'rest' => esc_url_raw(rest_url('quiz-lab/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'strings' => [
                'login_required' => 'برای شرکت در این آزمون باید وارد حساب شوید.',
                'start_error' => 'شروع آزمون ناموفق بود.',
                'unknown_error' => 'خطای نامشخص',
                'confirm_leave' => 'اگر صفحه را ببندید یا رفرش کنید، آزمون لغو می‌شود.',
                'time_over' => 'زمان آزمون تمام شد و پاسخ ثبت شد.',
                'select_option' => 'لطفاً یک گزینه انتخاب کن.',
                'redirecting' => 'در حال انتقال به صفحه نتیجه...',
            ],
        ]);
    }

    public static function enqueue_admin_assets($hook) {
        if ($hook !== 'post.php' && $hook !== 'post-new.php' && $hook !== 'toplevel_page_quiz-lab' && $hook !== 'quiz-lab_page_quiz-lab-results') return;

        wp_enqueue_style('quiz-lab-admin', QL_URL . 'assets/admin.css', [], QL_VERSION);

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && $screen->post_type === 'ql_quiz') {
            wp_enqueue_script('quiz-lab-admin', QL_URL . 'assets/admin.js', [], QL_VERSION, true);
        }
    }
}
