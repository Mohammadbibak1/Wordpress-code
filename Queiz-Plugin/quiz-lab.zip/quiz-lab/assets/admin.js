(function () {
  const root = document.getElementById("ql-questions-builder");
  const input = document.getElementById("ql_questions_input");
  if (!root || !input) return;

  let questions = [];
  try {
    questions = JSON.parse(root.dataset.questions || "[]") || [];
  } catch (e) {
    questions = [];
  }

  function sync() {
    input.value = JSON.stringify(questions);
  }

  function el(tag, attrs = {}, html = "") {
    const n = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === "class") n.className = v;
      else n.setAttribute(k, v);
    });
    if (html) n.innerHTML = html;
    return n;
  }

  function render() {
    root.innerHTML = "";

    const top = el("div", { class: "ql-admin-top" });
    const addQ = el("button", { type: "button", class: "button button-primary" }, "➕ افزودن سوال");
    addQ.onclick = () => {
      questions.push({ title: "", options: ["", ""], correct: 0 });
      sync(); render();
    };
    top.appendChild(addQ);
    root.appendChild(top);

    questions.forEach((q, qi) => {
      const card = el("div", { class: "ql-q-card" });

      const head = el("div", { class: "ql-q-head" }, `<b>سوال ${qi + 1}</b>`);
      const del = el("button", { type: "button", class: "button" }, "🗑 حذف");
      del.onclick = () => {
        questions.splice(qi, 1);
        sync(); render();
      };
      head.appendChild(del);
      card.appendChild(head);

      const title = el("input", { type: "text", class: "ql-q-title", placeholder: "متن سوال..." });
      title.value = q.title || "";
      title.oninput = (e) => { questions[qi].title = e.target.value; sync(); };
      card.appendChild(title);

      const optsWrap = el("div", { class: "ql-opts" });

      (q.options || []).forEach((opt, oi) => {
        const row = el("div", { class: "ql-opt-row" });

        const radio = el("input", { type: "radio", name: `ql_correct_${qi}` });
        radio.checked = (oi === (q.correct ?? 0));
        radio.onchange = () => { questions[qi].correct = oi; sync(); };

        const optIn = el("input", { type: "text", class: "ql-opt-input", placeholder: `گزینه ${oi + 1}` });
        optIn.value = opt || "";
        optIn.oninput = (e) => { questions[qi].options[oi] = e.target.value; sync(); };

        const delOpt = el("button", { type: "button", class: "button" }, "×");
        delOpt.onclick = () => {
          if (questions[qi].options.length <= 2) return alert("حداقل ۲ گزینه لازم است.");
          questions[qi].options.splice(oi, 1);
          if (questions[qi].correct >= questions[qi].options.length) questions[qi].correct = 0;
          sync(); render();
        };

        row.appendChild(radio);
        row.appendChild(optIn);
        row.appendChild(delOpt);
        optsWrap.appendChild(row);
      });

      const addOpt = el("button", { type: "button", class: "button" }, "➕ افزودن گزینه");
      addOpt.onclick = () => {
        questions[qi].options.push("");
        sync(); render();
      };

      card.appendChild(optsWrap);
      card.appendChild(addOpt);

      root.appendChild(card);
    });

    sync();
  }

  render();
})();