<?php
if (!defined('ABSPATH')) exit;

function ql_json_decode($str, $default = []) {
  if (!is_string($str) || trim($str) === '') return $default;
  $data = json_decode($str, true);
  return is_array($data) ? $data : $default;
}

function ql_json_encode($arr) {
  return wp_json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function ql_ip_hash() {
  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  return $ip ? hash('sha256', $ip . '|' . wp_salt('auth')) : null;
}

function ql_get_quiz($quiz_id) {
  global $wpdb;
  $t = ql_db_tables();
  return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['quizzes']} WHERE id=%d", $quiz_id), ARRAY_A);
}

function ql_get_questions($quiz_id) {
  global $wpdb;
  $t = ql_db_tables();
  return $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$t['questions']} WHERE quiz_id=%d ORDER BY sort_order ASC, id ASC",
    $quiz_id
  ), ARRAY_A);
}

function ql_get_options_by_question_ids($question_ids) {
  global $wpdb;
  $t = ql_db_tables();
  if (empty($question_ids)) return [];
  $in = implode(',', array_map('absint', $question_ids));
  $rows = $wpdb->get_results("SELECT * FROM {$t['options']} WHERE question_id IN ($in) ORDER BY sort_order ASC, id ASC", ARRAY_A);
  $map = [];
  foreach ($rows as $r) {
    $map[(int)$r['question_id']][] = $r;
  }
  return $map;
}

function ql_get_rules($quiz_id) {
  global $wpdb;
  $t = ql_db_tables();
  return $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$t['rules']} WHERE quiz_id=%d AND enabled=1 ORDER BY priority ASC, id ASC",
    $quiz_id
  ), ARRAY_A);
}

/**
 * score_json format per option:
 * {
 *   "total": 2,
 *   "dims": {"E":2, "I":0, "S":1, "N":0, "T":0, "F":0, "J":0, "P":0},
 *   "cats": {"leadership": 1}
 * }
 */
function ql_compute_scores($quiz, $questions, $options_map, $answers) {
  $total = 0;
  $dims = ["E"=>0,"I"=>0,"S"=>0,"N"=>0,"T"=>0,"F"=>0,"J"=>0,"P"=>0];
  $cats = [];

  // option lookup by id
  $opt_lookup = [];
  foreach ($options_map as $qid => $opts) {
    foreach ($opts as $opt) {
      $opt_lookup[(int)$opt['id']] = $opt;
    }
  }

  foreach ($answers as $qid => $selected) {
    $selected_ids = is_array($selected) ? $selected : [$selected];
    foreach ($selected_ids as $opt_id) {
      $opt_id = absint($opt_id);
      if (!$opt_id || empty($opt_lookup[$opt_id])) continue;

      $score = ql_json_decode($opt_lookup[$opt_id]['score_json'], []);
      $total += (int)($score['total'] ?? 0);

      if (!empty($score['dims']) && is_array($score['dims'])) {
        foreach ($score['dims'] as $k => $v) {
          $k = strtoupper(trim((string)$k));
          if (!isset($dims[$k])) continue;
          $dims[$k] += (int)$v;
        }
      }

      if (!empty($score['cats']) && is_array($score['cats'])) {
        foreach ($score['cats'] as $k => $v) {
          $k = sanitize_key($k);
          $cats[$k] = (int)($cats[$k] ?? 0) + (int)$v;
        }
      }
    }
  }

  $mbti = null;
  if (($quiz['quiz_type'] ?? 'normal') === 'mbti') {
    $mbti = ql_mbti_from_dims($dims);
  }

  return [
    'total' => $total,
    'dims'  => $dims,
    'cats'  => $cats,
    'mbti'  => $mbti,
  ];
}

function ql_mbti_from_dims($dims) {
  // tie-breaker: if equal -> choose second letter (I, N, F, P)
  $E = (int)($dims['E'] ?? 0); $I = (int)($dims['I'] ?? 0);
  $S = (int)($dims['S'] ?? 0); $N = (int)($dims['N'] ?? 0);
  $T = (int)($dims['T'] ?? 0); $F = (int)($dims['F'] ?? 0);
  $J = (int)($dims['J'] ?? 0); $P = (int)($dims['P'] ?? 0);

  $r1 = ($E > $I) ? 'E' : (($I > $E) ? 'I' : 'I');
  $r2 = ($S > $N) ? 'S' : (($N > $S) ? 'N' : 'N');
  $r3 = ($T > $F) ? 'T' : (($F > $T) ? 'F' : 'F');
  $r4 = ($J > $P) ? 'J' : (($P > $J) ? 'P' : 'P');

  return $r1.$r2.$r3.$r4;
}

/**
 * Condition JSON formats (MVP):
 * 1) {"type":"score_total","op":">=","value":80}
 * 2) {"type":"mbti_is","value":"INTJ"}
 * 3) {"type":"dim_compare","left":"E","op":">","right":"I"}
 * 4) {"type":"answer_is","question_id":12,"option_id":55}
 * 5) {"all":[ <cond1>, <cond2> ]}  OR  {"any":[ ... ]}
 */
function ql_eval_condition($cond, $context) {
  if (!is_array($cond)) return false;

  if (isset($cond['all']) && is_array($cond['all'])) {
    foreach ($cond['all'] as $c) if (!ql_eval_condition($c, $context)) return false;
    return true;
  }
  if (isset($cond['any']) && is_array($cond['any'])) {
    foreach ($cond['any'] as $c) if (ql_eval_condition($c, $context)) return true;
    return false;
  }

  $type = $cond['type'] ?? '';
  $scores = $context['scores'] ?? [];
  $answers = $context['answers'] ?? [];

  if ($type === 'score_total') {
    $op = $cond['op'] ?? '>=';
    $value = (int)($cond['value'] ?? 0);
    return ql_compare((int)($scores['total'] ?? 0), $op, $value);
  }

  if ($type === 'mbti_is') {
    $value = strtoupper(trim((string)($cond['value'] ?? '')));
    return $value !== '' && strtoupper((string)($scores['mbti'] ?? '')) === $value;
  }

  if ($type === 'dim_compare') {
    $left  = strtoupper(trim((string)($cond['left'] ?? '')));
    $right = strtoupper(trim((string)($cond['right'] ?? '')));
    $op = $cond['op'] ?? '>';
    $dims = $scores['dims'] ?? [];
    if (!isset($dims[$left]) || !isset($dims[$right])) return false;
    return ql_compare((int)$dims[$left], $op, (int)$dims[$right]);
  }

  if ($type === 'answer_is') {
    $qid = absint($cond['question_id'] ?? 0);
    $oid = absint($cond['option_id'] ?? 0);
    if (!$qid || !$oid) return false;
    if (!isset($answers[$qid])) return false;
    $sel = $answers[$qid];
    if (is_array($sel)) return in_array($oid, array_map('absint', $sel), true);
    return absint($sel) === $oid;
  }

  return false;
}

function ql_compare($a, $op, $b) {
  switch ($op) {
    case '>':  return $a >  $b;
    case '>=': return $a >= $b;
    case '<':  return $a <  $b;
    case '<=': return $a <= $b;
    case '==': return $a == $b;
    case '!=': return $a != $b;
    default:   return false;
  }
}

/**
 * Pick first matching rule by priority. Returns action array.
 * action_json example:
 * {"type":"redirect","url":"https://site.com/page-a"}
 * or {"type":"show_result","title":"نتیجه A","text":"..."}
 */
function ql_pick_action_by_rules($quiz_id, $context) {
  $rules = ql_get_rules($quiz_id);
  foreach ($rules as $r) {
    $cond = ql_json_decode($r['condition_json'], []);
    if (ql_eval_condition($cond, $context)) {
      return ql_json_decode($r['action_json'], []);
    }
  }
  return ['type' => 'show_result', 'title' => 'نتیجه', 'text' => 'نتیجه‌ای برای شما محاسبه شد.'];
}

function ql_save_attempt($quiz_id, $answers, $result) {
  global $wpdb;
  $t = ql_db_tables();

  $wpdb->insert($t['attempts'], [
    'quiz_id'      => absint($quiz_id),
    'user_id'      => get_current_user_id() ?: null,
    'session_key'  => substr(hash('sha256', wp_get_session_token() . '|' . wp_salt()), 0, 64),
    'answers_json' => ql_json_encode($answers),
    'result_json'  => ql_json_encode($result),
    'ip_hash'      => ql_ip_hash(),
  ], ['%d','%d','%s','%s','%s','%s']);

  return (int)$wpdb->insert_id;
}

/**
 * Submission handler: validate required, compute scores, apply rule action, save attempt, redirect if needed.
 */
function ql_handle_submission_and_maybe_redirect() {
  $quiz_id = absint($_POST['quiz_id'] ?? 0);
  if (!$quiz_id) wp_die('Quiz ID missing.');

  if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ql_submit_quiz_' . $quiz_id)) {
    wp_die('Security check failed.');
  }

  $quiz = ql_get_quiz($quiz_id);
  if (!$quiz) wp_die('Quiz not found.');

  $questions = ql_get_questions($quiz_id);
  $qids = array_map(fn($q) => (int)$q['id'], $questions);
  $options_map = ql_get_options_by_question_ids($qids);

  // Collect answers
  $answers = [];
  foreach ($questions as $q) {
    $qid = (int)$q['id'];
    $key = 'q_' . $qid;

    if ($q['question_type'] === 'multi') {
      $val = isset($_POST[$key]) ? (array)$_POST[$key] : [];
      $val = array_values(array_filter(array_map('absint', $val)));
      if (!empty($val)) $answers[$qid] = $val;
    } else {
      $val = absint($_POST[$key] ?? 0);
      if ($val) $answers[$qid] = $val;
    }
  }

  // Validate required
  $errors = [];
  foreach ($questions as $q) {
    $qid = (int)$q['id'];
    if ((int)$q['is_required'] !== 1) continue;
    if (!isset($answers[$qid]) || (is_array($answers[$qid]) && empty($answers[$qid]))) {
      $errors[] = 'سؤال الزامی بدون پاسخ: ' . wp_strip_all_tags($q['title']);
    }
  }

  if (!empty($errors)) {
    set_transient('ql_submit_errors_' . $quiz_id . '_' . (get_current_user_id() ?: 'guest'), $errors, 60);
    wp_safe_redirect(wp_get_referer() ?: home_url('/'));
    exit;
  }

  $scores = ql_compute_scores($quiz, $questions, $options_map, $answers);

  $context = [
    'quiz' => $quiz,
    'scores' => $scores,
    'answers' => $answers,
  ];

  $action = ql_pick_action_by_rules($quiz_id, $context);

  $result = [
    'scores' => $scores,
    'action' => $action,
  ];

  $attempt_id = ql_save_attempt($quiz_id, $answers, $result);

  if (($action['type'] ?? '') === 'redirect') {
    $url = trim((string)($action['url'] ?? ''));
    if ($url) {
      $url = add_query_arg(['ql_attempt' => $attempt_id], $url);
      wp_safe_redirect($url);
      exit;
    }
  }

  set_transient('ql_last_result_' . $quiz_id . '_' . (get_current_user_id() ?: 'guest'), $result, 300);
  wp_safe_redirect(wp_get_referer() ?: home_url('/'));
  exit;
}
