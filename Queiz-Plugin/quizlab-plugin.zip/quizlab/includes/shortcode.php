<?php
if (!defined('ABSPATH')) exit;

add_shortcode('quizlab', 'ql_shortcode_quiz');

function ql_shortcode_quiz($atts) {
  $atts = shortcode_atts(['id' => 0, 'show_title' => 1], $atts);
  $quiz_id = absint($atts['id']);
  if (!$quiz_id) return '<div>Quiz ID is required.</div>';

  $quiz = ql_get_quiz($quiz_id);
  if (!$quiz) return '<div>Quiz not found.</div>';

  $questions = ql_get_questions($quiz_id);
  $qids = array_map(fn($q) => (int)$q['id'], $questions);
  $options_map = ql_get_options_by_question_ids($qids);

  $user_key = (get_current_user_id() ?: 'guest');
  $errors = get_transient('ql_submit_errors_' . $quiz_id . '_' . $user_key);
  if ($errors) delete_transient('ql_submit_errors_' . $quiz_id . '_' . $user_key);

  $result = get_transient('ql_last_result_' . $quiz_id . '_' . $user_key);
  if ($result) delete_transient('ql_last_result_' . $quiz_id . '_' . $user_key);

  ob_start();
  ?>
  <div class="quizlab-wrap" style="border:1px solid #e5e5e5;padding:16px;border-radius:12px;">
    <?php if ((int)$atts['show_title'] === 1): ?>
      <h3 style="margin:0 0 12px;"><?php echo esc_html($quiz['title']); ?></h3>
    <?php endif; ?>

    <?php if (!empty($quiz['description'])): ?>
      <div style="margin-bottom:12px;opacity:.85"><?php echo wp_kses_post(wpautop($quiz['description'])); ?></div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
      <div style="background:#ffe8e8;border:1px solid #ffbaba;padding:10px;border-radius:10px;margin:10px 0;">
        <strong>خطا:</strong>
        <ul style="margin:8px 0 0; padding:0 18px;">
          <?php foreach ($errors as $e): ?>
            <li><?php echo esc_html($e); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if (!empty($result) && ($result['action']['type'] ?? '') === 'show_result'): ?>
      <div style="background:#eef8ff;border:1px solid #bfe6ff;padding:12px;border-radius:10px;margin:10px 0;">
        <h4 style="margin:0 0 6px;"><?php echo esc_html($result['action']['title'] ?? 'نتیجه'); ?></h4>
        <div style="opacity:.9"><?php echo wp_kses_post(wpautop($result['action']['text'] ?? '')); ?></div>

        <?php if (!empty($result['scores']['mbti'])): ?>
          <div style="margin-top:10px;font-weight:700;">MBTI: <?php echo esc_html($result['scores']['mbti']); ?></div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <form method="post">
      <input type="hidden" name="ql_action" value="submit_quiz">
      <input type="hidden" name="quiz_id" value="<?php echo esc_attr($quiz_id); ?>">
      <?php wp_nonce_field('ql_submit_quiz_' . $quiz_id); ?>

      <?php foreach ($questions as $q):
        $qid = (int)$q['id'];
        $opts = $options_map[$qid] ?? [];
        ?>
        <div style="padding:12px;margin:12px 0;border:1px solid #eee;border-radius:12px;">
          <div style="font-weight:600;margin-bottom:10px;">
            <?php echo wp_kses_post($q['title']); ?>
            <?php if ((int)$q['is_required'] === 1): ?>
              <span style="color:#d00;">*</span>
            <?php endif; ?>
          </div>

          <?php if ($q['question_type'] === 'multi'): ?>
            <?php foreach ($opts as $opt): ?>
              <label style="display:block;margin:8px 0;">
                <input type="checkbox" name="q_<?php echo esc_attr($qid); ?>[]" value="<?php echo esc_attr($opt['id']); ?>">
                <?php echo wp_kses_post($opt['title']); ?>
              </label>
            <?php endforeach; ?>
          <?php else: ?>
            <?php foreach ($opts as $opt): ?>
              <label style="display:block;margin:8px 0;">
                <input type="radio" name="q_<?php echo esc_attr($qid); ?>" value="<?php echo esc_attr($opt['id']); ?>">
                <?php echo wp_kses_post($opt['title']); ?>
              </label>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>

      <button type="submit" style="padding:10px 16px;border-radius:10px;border:0;background:#111;color:#fff;cursor:pointer;">
        ثبت آزمون
      </button>
    </form>
  </div>
  <?php
  return ob_get_clean();
}
