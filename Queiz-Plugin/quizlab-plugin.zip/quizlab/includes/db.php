<?php
if (!defined('ABSPATH')) exit;

function ql_db_tables() {
  global $wpdb;
  return [
    'quizzes'   => $wpdb->prefix . 'ql_quizzes',
    'questions' => $wpdb->prefix . 'ql_questions',
    'options'   => $wpdb->prefix . 'ql_options',
    'rules'     => $wpdb->prefix . 'ql_rules',
    'attempts'  => $wpdb->prefix . 'ql_attempts',
  ];
}

function ql_db_install() {
  global $wpdb;
  require_once ABSPATH . 'wp-admin/includes/upgrade.php';

  $charset_collate = $wpdb->get_charset_collate();
  $t = ql_db_tables();

  $sql = [];

  $sql[] = "CREATE TABLE {$t['quizzes']} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description LONGTEXT NULL,
    quiz_type VARCHAR(20) NOT NULL DEFAULT 'normal', /* normal|mbti */
    settings_json LONGTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    PRIMARY KEY (id)
  ) $charset_collate;";

  $sql[] = "CREATE TABLE {$t['questions']} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    quiz_id BIGINT UNSIGNED NOT NULL,
    title LONGTEXT NOT NULL,
    question_type VARCHAR(20) NOT NULL DEFAULT 'single', /* single|multi */
    is_required TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    meta_json LONGTEXT NULL,
    PRIMARY KEY (id),
    KEY quiz_id (quiz_id)
  ) $charset_collate;";

  $sql[] = "CREATE TABLE {$t['options']} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    question_id BIGINT UNSIGNED NOT NULL,
    title LONGTEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    score_json LONGTEXT NULL,
    PRIMARY KEY (id),
    KEY question_id (question_id)
  ) $charset_collate;";

  $sql[] = "CREATE TABLE {$t['rules']} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    quiz_id BIGINT UNSIGNED NOT NULL,
    priority INT NOT NULL DEFAULT 10,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    condition_json LONGTEXT NOT NULL,
    action_json LONGTEXT NOT NULL,
    PRIMARY KEY (id),
    KEY quiz_id (quiz_id),
    KEY priority (priority)
  ) $charset_collate;";

  $sql[] = "CREATE TABLE {$t['attempts']} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    quiz_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    session_key VARCHAR(64) NULL,
    answers_json LONGTEXT NOT NULL,
    result_json LONGTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip_hash VARCHAR(64) NULL,
    PRIMARY KEY (id),
    KEY quiz_id (quiz_id),
    KEY user_id (user_id)
  ) $charset_collate;";

  foreach ($sql as $q) {
    dbDelta($q);
  }

  add_option('ql_version', QL_VERSION);
}
