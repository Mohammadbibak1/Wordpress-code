<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
  add_menu_page(
    'QuizLab',
    'QuizLab',
    'manage_options',
    'quizlab',
    'ql_admin_page',
    'dashicons-welcome-learn-more',
    58
  );
});

function ql_admin_page() {
  if (!current_user_can('manage_options')) return;

  global $wpdb;
  $t = ql_db_tables();

  $view = sanitize_key($_GET['view'] ?? 'quizzes');
  $quiz_id = absint($_GET['quiz_id'] ?? 0);

  if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('ql_admin_action')) {
    $action = sanitize_key($_POST['action_name'] ?? '');

    if ($action === 'add_quiz') {
      $title = sanitize_text_field($_POST['title'] ?? '');
      $desc  = wp_kses_post($_POST['description'] ?? '');
      $type  = in_array($_POST['quiz_type'] ?? 'normal', ['normal','mbti'], true) ? $_POST['quiz_type'] : 'normal';

      $wpdb->insert($t['quizzes'], [
        'title' => $title,
        'description' => $desc,
        'quiz_type' => $type,
        'settings_json' => ql_json_encode([]),
      ]);

      echo '<div class="notice notice-success"><p>آزمون ساخته شد.</p></div>';
      $view = 'quizzes';
    }

    if ($action === 'add_question' && $quiz_id) {
      $title = wp_kses_post($_POST['title'] ?? '');
      $qtype = in_array($_POST['question_type'] ?? 'single', ['single','multi'], true) ? $_POST['question_type'] : 'single';
      $req   = !empty($_POST['is_required']) ? 1 : 0;
      $order = (int)($_POST['sort_order'] ?? 0);

      $wpdb->insert($t['questions'], [
        'quiz_id' => $quiz_id,
        'title' => $title,
        'question_type' => $qtype,
        'is_required' => $req,
        'sort_order' => $order,
        'meta_json' => ql_json_encode([]),
      ]);

      echo '<div class="notice notice-success"><p>سوال اضافه شد.</p></div>';
      $view = 'questions';
    }

    if ($action === 'add_option' && $quiz_id) {
      $question_id = absint($_POST['question_id'] ?? 0);
      $title = wp_kses_post($_POST['title'] ?? '');
      $order = (int)($_POST['sort_order'] ?? 0);

      $score_json_raw = trim((string)($_POST['score_json'] ?? ''));
      $score_json = ql_json_decode($score_json_raw, null);
      if ($score_json === null) $score_json = [];

      if ($question_id) {
        $wpdb->insert($t['options'], [
          'question_id' => $question_id,
          'title' => $title,
          'sort_order' => $order,
          'score_json' => ql_json_encode($score_json),
        ]);
        echo '<div class="notice notice-success"><p>گزینه اضافه شد.</p></div>';
      }
      $view = 'options';
    }

    if ($action === 'add_rule' && $quiz_id) {
      $priority = (int)($_POST['priority'] ?? 10);
      $enabled  = !empty($_POST['enabled']) ? 1 : 0;

      $cond_raw = trim((string)($_POST['condition_json'] ?? ''));
      $act_raw  = trim((string)($_POST['action_json'] ?? ''));

      $cond = ql_json_decode($cond_raw, null);
      $act  = ql_json_decode($act_raw, null);

      if ($cond === null || $act === null) {
        echo '<div class="notice notice-error"><p>JSON شرط یا اکشن معتبر نیست.</p></div>';
      } else {
        $wpdb->insert($t['rules'], [
          'quiz_id' => $quiz_id,
          'priority' => $priority,
          'enabled' => $enabled,
          'condition_json' => ql_json_encode($cond),
          'action_json' => ql_json_encode($act),
        ]);
        echo '<div class="notice notice-success"><p>Rule اضافه شد.</p></div>';
      }

      $view = 'rules';
    }
  }

  echo '<div class="wrap"><h1>QuizLab</h1>';

  $tabs = [
    'quizzes' => 'آزمون‌ها',
  ];
  if ($quiz_id) {
    $tabs['questions'] = 'سوال‌ها';
    $tabs['options'] = 'گزینه‌ها';
    $tabs['rules'] = 'شرط‌ها (Rules)';
  }

  echo '<h2 class="nav-tab-wrapper">';
  foreach ($tabs as $k => $label) {
    $url = admin_url('admin.php?page=quizlab&view=' . $k . ($quiz_id ? '&quiz_id='.$quiz_id : ''));
    $class = ($view === $k) ? 'nav-tab nav-tab-active' : 'nav-tab';
    echo '<a class="'.esc_attr($class).'" href="'.esc_url($url).'">'.esc_html($label).'</a>';
  }
  echo '</h2>';

  if ($view === 'quizzes') {
    ql_admin_view_quizzes();
  } elseif ($view === 'questions' && $quiz_id) {
    ql_admin_view_questions($quiz_id);
  } elseif ($view === 'options' && $quiz_id) {
    ql_admin_view_options($quiz_id);
  } elseif ($view === 'rules' && $quiz_id) {
    ql_admin_view_rules($quiz_id);
  }

  echo '</div>';
}

function ql_admin_view_quizzes() {
  global $wpdb;
  $t = ql_db_tables();
  $rows = $wpdb->get_results("SELECT * FROM {$t['quizzes']} ORDER BY id DESC", ARRAY_A);
  ?>
  <h2>ایجاد آزمون جدید</h2>
  <form method="post">
    <?php wp_nonce_field('ql_admin_action'); ?>
    <input type="hidden" name="action_name" value="add_quiz">
    <table class="form-table">
      <tr>
        <th><label>عنوان</label></th>
        <td><input type="text" name="title" class="regular-text" required></td>
      </tr>
      <tr>
        <th><label>نوع آزمون</label></th>
        <td>
          <select name="quiz_type">
            <option value="normal">Normal</option>
            <option value="mbti">MBTI</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label>توضیحات</label></th>
        <td><textarea name="description" rows="4" class="large-text"></textarea></td>
      </tr>
    </table>
    <?php submit_button('ساخت آزمون'); ?>
  </form>

  <hr>

  <h2>لیست آزمون‌ها</h2>
  <table class="widefat striped">
    <thead>
      <tr>
        <th>ID</th><th>عنوان</th><th>نوع</th><th>شورت‌کد</th><th>مدیریت</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?php echo esc_html($r['id']); ?></td>
          <td><?php echo esc_html($r['title']); ?></td>
          <td><?php echo esc_html($r['quiz_type']); ?></td>
          <td><code>[quizlab id="<?php echo esc_html($r['id']); ?>"]</code></td>
          <td>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=quizlab&view=questions&quiz_id='.$r['id'])); ?>">سوال‌ها</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=quizlab&view=options&quiz_id='.$r['id'])); ?>">گزینه‌ها</a>
            <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=quizlab&view=rules&quiz_id='.$r['id'])); ?>">Rules</a>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="5">هنوز آزمونی ساخته نشده.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  <?php
}

function ql_admin_view_questions($quiz_id) {
  global $wpdb;
  $t = ql_db_tables();
  $quiz = ql_get_quiz($quiz_id);
  $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['questions']} WHERE quiz_id=%d ORDER BY sort_order ASC, id ASC", $quiz_id), ARRAY_A);
  ?>
  <h2>سوال‌های آزمون: <?php echo esc_html($quiz['title'] ?? ''); ?></h2>

  <h3>افزودن سوال</h3>
  <form method="post">
    <?php wp_nonce_field('ql_admin_action'); ?>
    <input type="hidden" name="action_name" value="add_question">
    <table class="form-table">
      <tr>
        <th>متن سوال</th>
        <td><textarea name="title" rows="3" class="large-text" required></textarea></td>
      </tr>
      <tr>
        <th>نوع</th>
        <td>
          <select name="question_type">
            <option value="single">تک انتخابی</option>
            <option value="multi">چند انتخابی</option>
          </select>
        </td>
      </tr>
      <tr>
        <th>الزامی</th>
        <td><label><input type="checkbox" name="is_required" value="1" checked> بله</label></td>
      </tr>
      <tr>
        <th>ترتیب</th>
        <td><input type="number" name="sort_order" value="0"></td>
      </tr>
    </table>
    <?php submit_button('افزودن سوال'); ?>
  </form>

  <hr>

  <h3>لیست سوال‌ها</h3>
  <table class="widefat striped">
    <thead><tr><th>ID</th><th>سوال</th><th>نوع</th><th>الزامی</th><th>ترتیب</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?php echo esc_html($r['id']); ?></td>
          <td><?php echo wp_kses_post($r['title']); ?></td>
          <td><?php echo esc_html($r['question_type']); ?></td>
          <td><?php echo ((int)$r['is_required']===1) ? 'بله' : 'خیر'; ?></td>
          <td><?php echo esc_html($r['sort_order']); ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="5">سوالی ثبت نشده.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  <?php
}

function ql_admin_view_options($quiz_id) {
  global $wpdb;
  $t = ql_db_tables();
  $quiz = ql_get_quiz($quiz_id);
  $questions = ql_get_questions($quiz_id);

  $rows = $wpdb->get_results($wpdb->prepare("
    SELECT o.*, q.title as q_title
    FROM {$t['options']} o
    JOIN {$t['questions']} q ON q.id=o.question_id
    WHERE q.quiz_id=%d
    ORDER BY q.sort_order ASC, o.sort_order ASC, o.id ASC
  ", $quiz_id), ARRAY_A);
  ?>
  <h2>گزینه‌های آزمون: <?php echo esc_html($quiz['title'] ?? ''); ?></h2>

  <h3>افزودن گزینه</h3>
  <form method="post">
    <?php wp_nonce_field('ql_admin_action'); ?>
    <input type="hidden" name="action_name" value="add_option">

    <table class="form-table">
      <tr>
        <th>سوال</th>
        <td>
          <select name="question_id" required>
            <option value="">انتخاب سوال...</option>
            <?php foreach ($questions as $q): ?>
              <option value="<?php echo esc_attr($q['id']); ?>">
                #<?php echo esc_html($q['id']); ?> - <?php echo esc_html(wp_strip_all_tags($q['title'])); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </td>
      </tr>
      <tr>
        <th>متن گزینه</th>
        <td><textarea name="title" rows="2" class="large-text" required></textarea></td>
      </tr>
      <tr>
        <th>ترتیب</th>
        <td><input type="number" name="sort_order" value="0"></td>
      </tr>
      <tr>
        <th>امتیاز (JSON)</th>
        <td>
          <textarea name="score_json" rows="6" class="large-text" placeholder='مثال:
{"total":1,"dims":{"E":2},"cats":{"leadership":1}}'></textarea>
          <p class="description">
            برای MBTI از dims استفاده کن: E,I,S,N,T,F,J,P
          </p>
        </td>
      </tr>
    </table>

    <?php submit_button('افزودن گزینه'); ?>
  </form>

  <hr>

  <h3>لیست گزینه‌ها</h3>
  <table class="widefat striped">
    <thead><tr><th>ID</th><th>سوال</th><th>گزینه</th><th>امتیاز JSON</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?php echo esc_html($r['id']); ?></td>
          <td><?php echo esc_html(wp_strip_all_tags($r['q_title'])); ?></td>
          <td><?php echo wp_kses_post($r['title']); ?></td>
          <td><code><?php echo esc_html($r['score_json']); ?></code></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="4">گزینه‌ای ثبت نشده.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  <?php
}

function ql_admin_view_rules($quiz_id) {
  global $wpdb;
  $t = ql_db_tables();
  $quiz = ql_get_quiz($quiz_id);
  $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['rules']} WHERE quiz_id=%d ORDER BY priority ASC, id ASC", $quiz_id), ARRAY_A);
  ?>
  <h2>Rules آزمون: <?php echo esc_html($quiz['title'] ?? ''); ?></h2>

  <h3>افزودن Rule</h3>
  <p>Rule اولی که match بشه اجرا میشه (priority کمتر = زودتر).</p>

  <form method="post">
    <?php wp_nonce_field('ql_admin_action'); ?>
    <input type="hidden" name="action_name" value="add_rule">

    <table class="form-table">
      <tr>
        <th>Priority</th>
        <td><input type="number" name="priority" value="10"></td>
      </tr>
      <tr>
        <th>Enabled</th>
        <td><label><input type="checkbox" name="enabled" value="1" checked> فعال</label></td>
      </tr>
      <tr>
        <th>Condition JSON</th>
        <td>
          <textarea name="condition_json" rows="7" class="large-text" placeholder='مثال‌ها:
{"type":"mbti_is","value":"INTJ"}

{"type":"score_total","op":">=","value":80}

{"all":[
  {"type":"dim_compare","left":"E","op":">","right":"I"},
  {"type":"dim_compare","left":"T","op":">","right":"F"}
]}' required></textarea>
        </td>
      </tr>
      <tr>
        <th>Action JSON</th>
        <td>
          <textarea name="action_json" rows="6" class="large-text" placeholder='مثال:
{"type":"redirect","url":"https://site.com/intj"}

یا:
{"type":"show_result","title":"نتیجه A","text":"شما در این دسته هستید..."}' required></textarea>
        </td>
      </tr>
    </table>

    <?php submit_button('افزودن Rule'); ?>
  </form>

  <hr>

  <h3>لیست Rules</h3>
  <table class="widefat striped">
    <thead><tr><th>ID</th><th>Priority</th><th>Enabled</th><th>Condition</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?php echo esc_html($r['id']); ?></td>
          <td><?php echo esc_html($r['priority']); ?></td>
          <td><?php echo ((int)$r['enabled']===1) ? 'Yes' : 'No'; ?></td>
          <td><code><?php echo esc_html($r['condition_json']); ?></code></td>
          <td><code><?php echo esc_html($r['action_json']); ?></code></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="5">Rule ای ثبت نشده.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <hr>
  <h3>نمونه Rule های آماده MBTI</h3>
  <p><code>{"type":"mbti_is","value":"INTJ"}</code> → <code>{"type":"redirect","url":"https://site.com/intj"}</code></p>
  <?php
}
