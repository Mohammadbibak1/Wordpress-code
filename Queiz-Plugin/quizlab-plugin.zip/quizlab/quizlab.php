<?php
/**
 * Plugin Name: QuizLab (MVP)
 * Description: Lightweight quiz builder with scoring, MBTI dimensions, rules and redirects.
 * Version: 0.1.0
 * Author: محمد بی‌باک
 * Text Domain: quizlab
 */

if (!defined('ABSPATH')) exit;

define('QL_VERSION', '0.1.0');
define('QL_PATH', plugin_dir_path(__FILE__));
define('QL_URL', plugin_dir_url(__FILE__));

require_once QL_PATH . 'includes/db.php';
require_once QL_PATH . 'includes/helpers.php';
require_once QL_PATH . 'includes/shortcode.php';

if (is_admin()) {
  require_once QL_PATH . 'includes/admin/admin.php';
}

register_activation_hook(__FILE__, 'ql_activate_plugin');
function ql_activate_plugin() {
  ql_db_install();
}

/**
 * Handle quiz submissions early for redirect
 */
add_action('template_redirect', function () {
  if (empty($_POST['ql_action']) || $_POST['ql_action'] !== 'submit_quiz') return;
  ql_handle_submission_and_maybe_redirect();
});
