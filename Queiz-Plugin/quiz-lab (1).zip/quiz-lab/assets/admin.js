(function () {
  const root = document.getElementById("ql-questions-builder");
  const input = document.getElementById("ql_questions_input");
  if (!root || !input) return;

  let questions = [];
  try { questions = JSON.parse(root.dataset.questions || "[]") || []; } catch (e) { questions = []; }

  const MAX_Q = 200;

  function sync() { input.value = JSON.stringify(questions); }

  function el(tag, attrs = {}, html = "") {
    const n = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === "class") n.className = v;
      else n.setAttribute(k, v);
    });
    if (html) n.innerHTML = html;
    return n;
  }

  function toast(msg) {
    const t = el("div", { class: "ql-toast" }, msg);
    document.body.appendChild(t);
    setTimeout(() => t.classList.add("ql-toast--show"), 10);
    setTimeout(() => { t.classList.remove("ql-toast--show"); setTimeout(()=>t.remove(), 300); }, 2500);
  }

  function render() {
    root.innerHTML = "";

    const header = el("div", { class: "ql-builder__header" });
    header.appendChild(el("div", { class: "ql-builder__title" }, "سازنده سوالات"));

    const actions = el("div", { class: "ql-builder__actions" });
    const addQ = el("button", { type: "button", class: "button button-primary" }, "➕ افزودن سوال");
    addQ.onclick = () => {
      if (questions.length >= MAX_Q) return toast("تعداد سوال‌ها خیلی زیاد است.");
      questions.push({ title: "", options: ["", ""], correct: 0 });
      sync(); render();
    };

    const tip = el("span", { class: "ql-builder__tip" }, "دایره کنار گزینه = پاسخ صحیح");
    actions.appendChild(tip);
    actions.appendChild(addQ);

    header.appendChild(actions);
    root.appendChild(header);

    if (!questions.length) {
      root.appendChild(el("div", { class: "ql-empty" }, "هنوز سوالی ساخته نشده. روی «افزودن سوال» بزن."));
      sync();
      return;
    }

    questions.forEach((q, qi) => {
      const card = el("div", { class: "ql-q-card" });

      const head = el("div", { class: "ql-q-head" });
      head.appendChild(el("div", { class: "ql-q-head__left" }, `<b>سوال ${qi + 1}</b>`));

      const headActions = el("div", { class: "ql-q-head__actions" });

      const up = el("button", { type: "button", class: "button" }, "↑");
      up.title = "بالا";
      up.onclick = () => {
        if (qi === 0) return;
        const tmp = questions[qi-1]; questions[qi-1] = questions[qi]; questions[qi] = tmp;
        sync(); render();
      };

      const down = el("button", { type: "button", class: "button" }, "↓");
      down.title = "پایین";
      down.onclick = () => {
        if (qi === questions.length-1) return;
        const tmp = questions[qi+1]; questions[qi+1] = questions[qi]; questions[qi] = tmp;
        sync(); render();
      };

      const del = el("button", { type: "button", class: "button button-link-delete" }, "حذف");
      del.onclick = () => {
        if (!confirm("این سوال حذف شود؟")) return;
        questions.splice(qi, 1);
        sync(); render();
      };

      headActions.appendChild(up);
      headActions.appendChild(down);
      headActions.appendChild(del);

      head.appendChild(headActions);
      card.appendChild(head);

      const title = el("input", { type: "text", class: "ql-control", placeholder: "متن سوال..." });
      title.value = q.title || "";
      title.oninput = (e) => { questions[qi].title = e.target.value; sync(); };
      card.appendChild(title);

      const optsWrap = el("div", { class: "ql-opts" });

      (q.options || []).forEach((opt, oi) => {
        const row = el("div", { class: "ql-opt-row" });

        const radio = el("input", { type: "radio", name: `ql_correct_${qi}`, class: "ql-radio" });
        radio.checked = (oi === (q.correct ?? 0));
        radio.onchange = () => { questions[qi].correct = oi; sync(); };

        const optIn = el("input", { type: "text", class: "ql-control", placeholder: `گزینه ${oi + 1}` });
        optIn.value = opt || "";
        optIn.oninput = (e) => { questions[qi].options[oi] = e.target.value; sync(); };

        const delOpt = el("button", { type: "button", class: "button" }, "×");
        delOpt.title = "حذف گزینه";
        delOpt.onclick = () => {
          if (questions[qi].options.length <= 2) return toast("حداقل ۲ گزینه لازم است.");
          questions[qi].options.splice(oi, 1);
          if (questions[qi].correct >= questions[qi].options.length) questions[qi].correct = 0;
          sync(); render();
        };

        row.appendChild(radio);
        row.appendChild(optIn);
        row.appendChild(delOpt);
        optsWrap.appendChild(row);
      });

      const addOpt = el("button", { type: "button", class: "button" }, "➕ افزودن گزینه");
      addOpt.onclick = () => {
        questions[qi].options.push("");
        sync(); render();
      };

      card.appendChild(optsWrap);
      card.appendChild(addOpt);

      root.appendChild(card);
    });

    sync();
  }

  render();
})();