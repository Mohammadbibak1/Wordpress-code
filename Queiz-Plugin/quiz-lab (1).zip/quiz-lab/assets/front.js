(function () {
  const wrap = document.querySelector(".ql-wrap");
  if (!wrap || !window.QL) return;

  const quizId = parseInt(wrap.dataset.quizId, 10);
  const titleEl = wrap.querySelector(".ql-title");
  const timerPill = wrap.querySelector(".ql-pill--timer");
  const timerEl = wrap.querySelector(".ql-timer");
  const stepEl = wrap.querySelector(".ql-step");
  const bodyEl = wrap.querySelector(".ql-body");
  const prevBtn = wrap.querySelector(".ql-prev");
  const nextBtn = wrap.querySelector(".ql-next");
  const finishBtn = wrap.querySelector(".ql-finish");
  const resultEl = wrap.querySelector(".ql-result");
  const progressBar = wrap.querySelector(".ql-progress-bar");

  let quiz = null;
  let index = 0;
  let answers = {}; // {0: optionIndex, 1: optionIndex}
  let startTs = Date.now();
  let remaining = 0;
  let timerInt = null;
  let attemptId = 0;
  let finishing = false;

  function api(url, opts = {}) {
    return fetch(url, {
      ...opts,
      headers: {
        ...(opts.headers || {}),
        "Content-Type": "application/json",
        "X-WP-Nonce": QL.nonce,
      },
      keepalive: true,
    }).then(async r => {
      let data = {};
      try { data = await r.json(); } catch(e) { data = {}; }
      return { ok: r.ok, status: r.status, data };
    });
  }

  function setProgress() {
    const total = quiz.questions.length || 1;
    const p = Math.round(((index + 1) / total) * 100);
    progressBar.style.width = p + "%";
    stepEl.textContent = `سوال ${index + 1} از ${total}`;
  }

  function fmtTime(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  function warnOnLeave(enable) {
    if (!enable) {
      window.onbeforeunload = null;
      return;
    }
    window.onbeforeunload = function (e) {
      e.preventDefault();
      e.returnValue = QL.strings.confirm_leave;
      return e.returnValue;
    };
  }

  async function startAttempt() {
    const res = await api(`${QL.rest}/start`, { method: "POST", body: JSON.stringify({ quiz_id: quizId }) });
    if (!res.ok) throw new Error(res.data.message || QL.strings.start_error);
    attemptId = parseInt(res.data.attempt_id, 10) || 0;
  }

  function startTimer(limit) {
    if (!limit) { timerPill.style.display = "none"; return; }
    timerPill.style.display = "inline-flex";
    remaining = limit;
    timerEl.textContent = "⏳ " + fmtTime(remaining);

    timerInt = setInterval(() => {
      remaining--;
      timerEl.textContent = "⏳ " + fmtTime(Math.max(0, remaining));
      if (remaining <= 0) {
        clearInterval(timerInt);
        toast(QL.strings.time_over);
        doFinish();
      }
    }, 1000);
  }

  function toast(msg) {
    const t = document.createElement("div");
    t.className = "ql-toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add("ql-toast--show"), 10);
    setTimeout(() => { t.classList.remove("ql-toast--show"); setTimeout(()=>t.remove(), 300); }, 2500);
  }

  function renderQuestion() {
    const q = quiz.questions[index];
    titleEl.textContent = quiz.title || "";

    const htmlOpts = q.options.map((opt, oi) => {
      const checked = (answers[index] === oi) ? "checked" : "";
      return `
        <label class="ql-opt" role="button" tabindex="0">
          <input type="radio" name="ql_opt" value="${oi}" ${checked} />
          <span>${opt}</span>
        </label>
      `;
    }).join("");

    bodyEl.innerHTML = `
      <div class="ql-q">
        <div class="ql-q-title">${q.title || ""}</div>
        <div class="ql-opts">${htmlOpts}</div>
      </div>
    `;

    bodyEl.querySelectorAll('input[name="ql_opt"]').forEach(r => {
      r.addEventListener("change", (e) => {
        answers[index] = parseInt(e.target.value, 10);
      });
    });

    // کلیک روی لیبل برای بهتر شدن UX موبایل
    bodyEl.querySelectorAll(".ql-opt").forEach(label => {
      label.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          const inp = label.querySelector('input[type="radio"]');
          if (inp) { inp.checked = true; inp.dispatchEvent(new Event("change", { bubbles: true })); }
        }
      });
    });

    prevBtn.disabled = index === 0;
    const last = index === quiz.questions.length - 1;
    nextBtn.style.display = last ? "none" : "inline-flex";
    finishBtn.style.display = last ? "inline-flex" : "none";

    setProgress();
  }

  function go(delta) {
    const ni = index + delta;
    if (ni < 0 || ni >= quiz.questions.length) return;
    index = ni;
    renderQuestion();
  }

  async function abandonIfNeeded() {
    if (!attemptId || finishing) return;
    try { await api(`${QL.rest}/abandon`, { method: "POST", body: JSON.stringify({ attempt_id: attemptId }) }); }
    catch (e) {}
  }

  async function doFinish() {
    if (finishing) return;
    finishing = true;
    warnOnLeave(false);

    prevBtn.disabled = true;
    nextBtn.disabled = true;
    finishBtn.disabled = true;

    const timeSpent = Math.round((Date.now() - startTs) / 1000);
    const res = await api(`${QL.rest}/finish`, {
      method: "POST",
      body: JSON.stringify({
        quiz_id: quizId,
        attempt_id: attemptId,
        answers,
        time_spent: timeSpent
      })
    });

    if (!res.ok) {
      resultEl.style.display = "block";
      resultEl.innerHTML = `<div class="ql-alert ql-alert--error">خطا: ${res.data.message || QL.strings.unknown_error}</div>`;
      finishing = false;
      warnOnLeave(true);
      prevBtn.disabled = false;
      nextBtn.disabled = false;
      finishBtn.disabled = false;
      return;
    }

    resultEl.style.display = "block";
    resultEl.innerHTML = `
      <div class="ql-done">
        <h3>نتیجه آزمون</h3>
        <div class="ql-score">
          <div class="ql-score__main">${res.data.percent}%</div>
          <div class="ql-score__sub">امتیاز ${res.data.score} از ${res.data.max}</div>
        </div>
      </div>
    `;

    wrap.querySelector(".ql-actions").style.display = "none";
    bodyEl.style.display = "none";
    if (timerInt) clearInterval(timerInt);
    window.onbeforeunload = null;
  }

  prevBtn.addEventListener("click", () => go(-1));
  nextBtn.addEventListener("click", () => go(1));
  finishBtn.addEventListener("click", doFinish);

  // اگر کاربر صفحه را بست
  window.addEventListener("pagehide", abandonIfNeeded);
  window.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") abandonIfNeeded();
  });

  // init
  (async function init() {
    try {
      const qres = await fetch(`${QL.rest}/quiz/${quizId}`).then(r => r.json());
      quiz = qres;

      if (quiz.login_required && !QL.is_logged_in) {
        bodyEl.innerHTML = `<div class="ql-alert ql-alert--error">${QL.strings.login_required}</div>`;
        wrap.querySelector(".ql-actions").style.display = "none";
        return;
      }

      // start attempt
      await startAttempt();

      startTs = Date.now();
      warnOnLeave(true);
      startTimer(parseInt(quiz.time_limit || 0, 10));
      renderQuestion();
    } catch (e) {
      bodyEl.innerHTML = `<div class="ql-alert ql-alert--error">${(e && e.message) ? e.message : QL.strings.unknown_error}</div>`;
      wrap.querySelector(".ql-actions").style.display = "none";
    }
  })();
})();