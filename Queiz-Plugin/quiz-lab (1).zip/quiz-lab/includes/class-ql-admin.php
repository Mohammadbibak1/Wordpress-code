<?php
if (!defined('ABSPATH')) exit;

class QL_Admin {
    public static function menu() {
        add_menu_page(
            'Quiz Lab',
            'Quiz Lab',
            'manage_options',
            'quiz-lab',
            [self::class, 'page_quizzes'],
            'dashicons-welcome-learn-more',
            26
        );

        add_submenu_page(
            'quiz-lab',
            'آزمون‌ها',
            'آزمون‌ها',
            'manage_options',
            'edit.php?post_type=ql_quiz'
        );

        add_submenu_page(
            'quiz-lab',
            'دسته‌بندی‌ها',
            'دسته‌بندی‌ها',
            'manage_options',
            'edit-tags.php?taxonomy=ql_quiz_category&post_type=ql_quiz'
        );

        add_submenu_page(
            'quiz-lab',
            'نتایج',
            'نتایج',
            'manage_options',
            'quiz-lab-results',
            [self::class, 'page_results']
        );
    }

    public static function page_quizzes() {
        echo '<div class="wrap ql-admin-page">';
        echo '<h1>Quiz Lab</h1>';
        echo '<div class="ql-admin-hero">';
        echo '<div class="ql-admin-hero__text">';
        echo '<p style="margin:0 0 8px;">اینجا می‌تونی آزمون‌های حرفه‌ای بسازی و نتایج کاربران رو ببینی.</p>';
        echo '<p style="margin:0;color:#667085;">نسخه MVP: آزمون عادی (درست/غلط) + تایمر + ثبت نتایج</p>';
        echo '</div>';
        echo '<div class="ql-admin-hero__actions">';
        echo '<a class="button button-primary" href="' . admin_url('post-new.php?post_type=ql_quiz') . '">افزودن آزمون جدید</a> ';
        echo '<a class="button" href="' . admin_url('edit.php?post_type=ql_quiz') . '">مدیریت آزمون‌ها</a> ';
        echo '<a class="button" href="' . admin_url('admin.php?page=quiz-lab-results') . '">دیدن نتایج</a>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    public static function page_results() {
        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';

        $rows = $wpdb->get_results("SELECT * FROM $attempts ORDER BY id DESC LIMIT 100", ARRAY_A);

        echo '<div class="wrap ql-admin-page"><h1>نتایج آزمون‌ها (۱۰۰ مورد آخر)</h1>';

        echo '<table class="widefat striped ql-results-table">';
        echo '<thead><tr>
                <th>ID</th>
                <th>آزمون</th>
                <th>کاربر</th>
                <th>وضعیت</th>
                <th>امتیاز</th>
                <th>درصد</th>
                <th>زمان</th>
                <th>تاریخ</th>
              </tr></thead><tbody>';

        if (!$rows) {
            echo '<tr><td colspan="8">هنوز نتیجه‌ای ثبت نشده.</td></tr>';
        } else {
            foreach ($rows as $r) {
                $quiz_title = get_the_title((int)$r['quiz_id']);
                $user = 'مهمان';
                if ((int)$r['user_id']) {
                    $u = get_userdata((int)$r['user_id']);
                    $user = $u ? $u->user_login : 'کاربر';
                }
                $status_map = [
                    'started' => 'در حال انجام',
                    'finished' => 'تکمیل شده',
                    'abandoned' => 'لغو/بسته شده',
                ];
                $status = $status_map[$r['status']] ?? $r['status'];

                echo '<tr>';
                echo '<td>' . (int)$r['id'] . '</td>';
                echo '<td>' . esc_html($quiz_title ?: ('#'.$r['quiz_id'])) . '</td>';
                echo '<td>' . esc_html($user) . '</td>';
                echo '<td><span class="ql-badge ql-badge--' . esc_attr($r['status']) . '">' . esc_html($status) . '</span></td>';
                echo '<td>' . (int)$r['score'] . ' / ' . (int)$r['max_score'] . '</td>';
                echo '<td>' . (int)$r['percent'] . '%</td>';
                echo '<td>' . (int)$r['time_spent'] . ' ثانیه</td>';
                echo '<td>' . esc_html($r['created_at']) . '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table></div>';
    }

    public static function metaboxes() {
        add_meta_box(
            'ql_quiz_settings',
            'تنظیمات آزمون',
            [self::class, 'metabox_settings'],
            'ql_quiz',
            'normal',
            'high'
        );

        add_meta_box(
            'ql_quiz_questions',
            'سوالات آزمون',
            [self::class, 'metabox_questions'],
            'ql_quiz',
            'normal',
            'high'
        );
    }

    public static function metabox_settings($post) {
        $type = get_post_meta($post->ID, '_ql_type', true) ?: 'normal';
        $time_limit = (int) get_post_meta($post->ID, '_ql_time_limit', true);
        $login_required = (int) get_post_meta($post->ID, '_ql_login_required', true);

        wp_nonce_field('ql_save_quiz', 'ql_nonce');

        echo '<div class="ql-admin-card">';
        echo '<div class="ql-grid">';

        echo '<div class="ql-field">';
        echo '<label><b>نوع آزمون</b></label>';
        echo '<select class="ql-control" name="ql_type">
                <option value="normal" ' . selected($type, 'normal', false) . '>آزمون عادی (درست/غلط)</option>
                <option value="poll" disabled>نظرسنجی (به‌زودی)</option>
                <option value="personality" disabled>شخصیت‌شناسی/MBTI (به‌زودی)</option>
              </select>';
        echo '<small>در نسخه MVP فقط آزمون عادی فعال است.</small>';
        echo '</div>';

        echo '<div class="ql-field">';
        echo '<label><b>تایمر (ثانیه)</b></label>';
        echo '<input class="ql-control" type="number" name="ql_time_limit" value="' . esc_attr($time_limit) . '" min="0" />';
        echo '<small>۰ یعنی بدون تایمر.</small>';
        echo '</div>';

        echo '<div class="ql-field">';
        echo '<label><b>دسترسی</b></label>';
        echo '<label class="ql-check"><input type="checkbox" name="ql_login_required" value="1" ' . checked($login_required, 1, false) . ' /> فقط کاربران لاگین‌شده</label>';
        echo '<small>اگر فعال باشد، مهمان‌ها نمی‌توانند آزمون را شروع کنند.</small>';
        echo '</div>';

        echo '</div></div>';
    }

    public static function metabox_questions($post) {
        $questions = get_post_meta($post->ID, '_ql_questions', true);
        $questions = is_array($questions) ? $questions : [];

        echo '<div id="ql-questions-builder" class="ql-builder" data-questions="' . esc_attr(wp_json_encode($questions)) . '"></div>';
        echo '<input type="hidden" id="ql_questions_input" name="ql_questions_json" value="' . esc_attr(wp_json_encode($questions)) . '" />';
        echo '<p class="description">نکته: روی دایره کنار گزینه کلیک کن تا گزینه صحیح مشخص شود.</p>';
    }

    public static function save_quiz_meta($post_id, $post) {
        if (!isset($_POST['ql_nonce']) || !wp_verify_nonce($_POST['ql_nonce'], 'ql_save_quiz')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $type = isset($_POST['ql_type']) ? sanitize_text_field($_POST['ql_type']) : 'normal';
        update_post_meta($post_id, '_ql_type', $type);

        $time_limit = isset($_POST['ql_time_limit']) ? (int)$_POST['ql_time_limit'] : 0;
        update_post_meta($post_id, '_ql_time_limit', max(0, $time_limit));

        $login_required = ql_sanitize_bool($_POST['ql_login_required'] ?? 0);
        update_post_meta($post_id, '_ql_login_required', $login_required);

        $raw = wp_unslash($_POST['ql_questions_json'] ?? '');
        $arr = json_decode($raw, true);
        if (!is_array($arr)) $arr = [];

        $clean = [];
        foreach ($arr as $q) {
            $title = isset($q['title']) ? sanitize_text_field($q['title']) : '';
            $options = isset($q['options']) && is_array($q['options']) ? array_map('sanitize_text_field', $q['options']) : [];
            $correct = isset($q['correct']) ? (int)$q['correct'] : -1;

            // جلوگیری از سوال خالی یا گزینه‌های خالی زیاد
            $options = array_values(array_map(function($o){ return trim($o); }, $options));
            if (!$title || count($options) < 2) continue;

            $clean[] = [
                'title' => $title,
                'options' => $options,
                'correct' => $correct,
            ];
        }

        update_post_meta($post_id, '_ql_questions', $clean);
    }

    public static function shortcode($atts) {
        $atts = shortcode_atts(['id' => 0], $atts);
        $id = (int)$atts['id'];
        if (!$id) return '<div class="ql-alert">شناسه آزمون مشخص نیست.</div>';

        return '<div class="ql-wrap" data-quiz-id="' . esc_attr($id) . '">
            <div class="ql-card">
              <div class="ql-top">
                <div class="ql-title"></div>
                <div class="ql-meta">
                  <div class="ql-pill ql-pill--timer" style="display:none;"><span class="ql-timer"></span></div>
                  <div class="ql-pill ql-pill--step"><span class="ql-step"></span></div>
                </div>
              </div>

              <div class="ql-progress"><div class="ql-progress-bar"></div></div>

              <div class="ql-body"></div>

              <div class="ql-actions">
                <button class="ql-btn ql-btn--ghost ql-prev" type="button">قبلی</button>
                <button class="ql-btn ql-next" type="button">بعدی</button>
                <button class="ql-btn ql-finish" type="button" style="display:none;">ثبت و پایان</button>
              </div>

              <div class="ql-result" style="display:none;"></div>
            </div>
          </div>';
    }

    public static function enqueue_front_assets() {
        // فقط وقتی شورتکد روی صفحه وجود دارد
        if (!is_singular()) return;
        $post = get_post();
        if (!$post) return;
        if (stripos($post->post_content ?? '', '[quiz_lab') === false) return;

        wp_register_style('quiz-lab-front', QL_URL . 'assets/front.css', [], QL_VERSION);
        wp_register_script('quiz-lab-front', QL_URL . 'assets/front.js', [], QL_VERSION, true);

        wp_enqueue_style('quiz-lab-front');
        wp_enqueue_script('quiz-lab-front');

        wp_localize_script('quiz-lab-front', 'QL', [
            'rest' => esc_url_raw(rest_url('quiz-lab/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'strings' => [
                'login_required' => 'برای شرکت در این آزمون باید وارد حساب شوید.',
                'start_error' => 'شروع آزمون ناموفق بود.',
                'unknown_error' => 'خطای نامشخص',
                'confirm_leave' => 'اگر صفحه را ببندید یا رفرش کنید، آزمون لغو می‌شود.',
                'time_over' => 'زمان آزمون تمام شد و پاسخ ثبت شد.',
                'finish' => 'ثبت و پایان',
                'next' => 'بعدی',
                'prev' => 'قبلی',
            ],
        ]);
    }

    public static function enqueue_admin_assets($hook) {
        if ($hook !== 'post.php' && $hook !== 'post-new.php' && $hook !== 'toplevel_page_quiz-lab' && $hook !== 'quiz-lab_page_quiz-lab-results') return;

        wp_enqueue_style('quiz-lab-admin', QL_URL . 'assets/admin.css', [], QL_VERSION);

        // builder فقط داخل صفحه ویرایش آزمون
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && $screen->post_type === 'ql_quiz') {
            wp_enqueue_script('quiz-lab-admin', QL_URL . 'assets/admin.js', [], QL_VERSION, true);
        }
    }
}
