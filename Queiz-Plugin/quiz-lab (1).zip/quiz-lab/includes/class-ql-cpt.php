<?php
if (!defined('ABSPATH')) exit;

class QL_CPT {
    public static function register() {
        register_post_type('ql_quiz', [
            'labels' => [
                'name' => 'Quiz Lab',
                'singular_name' => 'آزمون',
                'add_new' => 'افزودن آزمون',
                'add_new_item' => 'افزودن آزمون جدید',
                'edit_item' => 'ویرایش آزمون',
                'new_item' => 'آزمون جدید',
                'view_item' => 'نمایش آزمون',
                'search_items' => 'جستجوی آزمون‌ها',
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false, // منو را خودمان می‌سازیم
            'menu_icon' => 'dashicons-welcome-learn-more',
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);

        register_taxonomy('ql_quiz_category', 'ql_quiz', [
            'labels' => [
                'name' => 'دسته‌بندی آزمون‌ها',
                'singular_name' => 'دسته آزمون',
            ],
            'public' => false,
            'show_ui' => true,
            'hierarchical' => true,
            'show_in_menu' => false,
        ]);
    }
}
