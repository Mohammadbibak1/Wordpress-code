<?php
if (!defined('ABSPATH')) exit;

class QL_REST {
    public static function routes() {
        register_rest_route('quiz-lab/v1', '/quiz/(?P<id>\d+)', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => [self::class, 'get_quiz'],
        ]);

        register_rest_route('quiz-lab/v1', '/start', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'check_nonce'],
            'callback' => [self::class, 'start_attempt'],
        ]);

        register_rest_route('quiz-lab/v1', '/abandon', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'check_nonce'],
            'callback' => [self::class, 'abandon_attempt'],
        ]);

        register_rest_route('quiz-lab/v1', '/finish', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'check_nonce'],
            'callback' => [self::class, 'finish_quiz'],
        ]);
    }

    public static function check_nonce(\WP_REST_Request $req) {
        $nonce = $req->get_header('X-WP-Nonce');
        return (bool) wp_verify_nonce($nonce, 'wp_rest');
    }

    public static function get_quiz(\WP_REST_Request $req) {
        $id = (int) $req['id'];
        $post = get_post($id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }

        $meta = ql_get_quiz_meta($id);

        // front-safe (بدون لو دادن جواب صحیح)
        $safe_questions = [];
        foreach ($meta['questions'] as $q) {
            $safe_questions[] = [
                'title' => isset($q['title']) ? (string)$q['title'] : '',
                'options' => isset($q['options']) && is_array($q['options']) ? array_values($q['options']) : [],
            ];
        }

        return new WP_REST_Response([
            'id' => $id,
            'title' => get_the_title($id),
            'type' => $meta['type'],
            'time_limit' => $meta['time_limit'],
            'login_required' => $meta['login_required'],
            'questions' => $safe_questions,
        ], 200);
    }

    public static function start_attempt(\WP_REST_Request $req) {
        $quiz_id = (int) $req->get_param('quiz_id');

        $post = get_post($quiz_id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }

        $meta = ql_get_quiz_meta($quiz_id);
        if (!empty($meta['login_required']) && !is_user_logged_in()) {
            return new WP_REST_Response(['message' => 'برای شروع آزمون باید وارد شوید'], 403);
        }

        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';

        $user_id = ql_user_id_or_zero();
        $session_key = $user_id ? '' : ql_get_or_set_guest_session_key();

        $wpdb->insert($attempts, [
            'quiz_id' => $quiz_id,
            'user_id' => $user_id,
            'session_key' => $session_key,
            'status' => 'started',
            'created_at' => ql_now_mysql(),
            'updated_at' => ql_now_mysql(),
        ], ['%d','%d','%s','%s','%s','%s']);

        $attempt_id = (int) $wpdb->insert_id;

        return new WP_REST_Response([
            'attempt_id' => $attempt_id,
        ], 200);
    }

    public static function abandon_attempt(\WP_REST_Request $req) {
        $attempt_id = (int) $req->get_param('attempt_id');
        if (!$attempt_id) return new WP_REST_Response(['ok' => true], 200);

        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';

        $wpdb->update($attempts, [
            'status' => 'abandoned',
            'updated_at' => ql_now_mysql(),
        ], ['id' => $attempt_id], ['%s','%s'], ['%d']);

        return new WP_REST_Response(['ok' => true], 200);
    }

    public static function finish_quiz(\WP_REST_Request $req) {
        $quiz_id = (int) $req->get_param('quiz_id');
        $attempt_id = (int) $req->get_param('attempt_id');
        $answers = (array) $req->get_param('answers');
        $time_spent = (int) $req->get_param('time_spent');

        $post = get_post($quiz_id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }

        $meta = ql_get_quiz_meta($quiz_id);

        if (!empty($meta['login_required']) && !is_user_logged_in()) {
            return new WP_REST_Response(['message' => 'برای شرکت در آزمون باید وارد شوید'], 403);
        }

        if ($meta['type'] !== 'normal') {
            return new WP_REST_Response(['message' => 'فعلاً فقط آزمون عادی فعال است'], 400);
        }

        $graded = QL_Engine::grade_normal($meta['questions'], $answers);

        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';
        $ans_tbl  = $wpdb->prefix . 'ql_attempt_answers';

        // اگر attempt_id معتبر نبود، یک attempt جدید بساز
        if (!$attempt_id) {
            $user_id = ql_user_id_or_zero();
            $session_key = $user_id ? '' : ql_get_or_set_guest_session_key();
            $wpdb->insert($attempts, [
                'quiz_id' => $quiz_id,
                'user_id' => $user_id,
                'session_key' => $session_key,
                'status' => 'finished',
                'score' => $graded['score'],
                'max_score' => $graded['max'],
                'percent' => $graded['percent'],
                'time_spent' => max(0, $time_spent),
                'created_at' => ql_now_mysql(),
                'updated_at' => ql_now_mysql(),
            ], ['%d','%d','%s','%s','%d','%d','%d','%d','%s','%s']);
            $attempt_id = (int) $wpdb->insert_id;
        } else {
            $wpdb->update($attempts, [
                'status' => 'finished',
                'score' => $graded['score'],
                'max_score' => $graded['max'],
                'percent' => $graded['percent'],
                'time_spent' => max(0, $time_spent),
                'updated_at' => ql_now_mysql(),
            ], ['id' => $attempt_id], ['%s','%d','%d','%d','%d','%s'], ['%d']);
        }

        // پاک کردن پاسخ‌های قبلی این attempt (اگر دوباره ارسال شد)
        $wpdb->delete($ans_tbl, ['attempt_id' => $attempt_id], ['%d']);

        foreach ($graded['details'] as $d) {
            $wpdb->insert($ans_tbl, [
                'attempt_id' => $attempt_id,
                'question_index' => (int)$d['question_index'],
                'selected_option' => (int)$d['selected'],
                'correct_option' => (int)$d['correct'],
                'is_correct' => (int)$d['is_correct'],
            ], ['%d','%d','%d','%d','%d']);
        }

        return new WP_REST_Response([
            'attempt_id' => $attempt_id,
            'score' => $graded['score'],
            'max' => $graded['max'],
            'percent' => $graded['percent'],
        ], 200);
    }
}
