/* Quiz Lab Admin Builder (RTL) */
window.QLAdmin = window.QLAdmin || {};

(function () {
  const root = document.getElementById('ql-questions-builder');
  if (!root) return;

  const input = document.getElementById('ql_questions_input');
  const quizType = root.dataset.type || 'normal';

  let personalityTypes = [];
  try { personalityTypes = JSON.parse(root.dataset.types || '[]'); } catch (e) {}

  // API برای بروزرسانی Type ها بدون رفرش
  window.QLAdmin.setPersonalityTypes = function(newTypes){
    personalityTypes = Array.isArray(newTypes) ? newTypes : [];
    render();
  };

  let questions = [];
  let _uid = 1;
  const collapsed = new Set();
  const ensureUid = (q) => { if (!q._uid) q._uid = (_uid++); return q._uid; };
  try { questions = JSON.parse(root.dataset.questions || '[]'); } catch (e) {}

  const esc = (s) => (String(s ?? '')).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));

  const el = (tag, attrs = {}, children = []) => {
    const n = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v);
    });
    (Array.isArray(children) ? children : [children]).filter(Boolean).forEach(c => n.appendChild(c));
    return n;
  };

  const toast = (msg) => {
    const t = el('div', { class: 'ql-toast', html: esc(msg) });
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('ql-toast--show'), 10);
    setTimeout(() => { t.classList.remove('ql-toast--show'); setTimeout(() => t.remove(), 300); }, 2200);
  };

  const save = () => {
    input.value = JSON.stringify(questions);
  };

  const normalize = () => {
    if (!Array.isArray(questions)) questions = [];
    questions = questions.map(q => {
      // مهم: _uid را حفظ کن تا حالت آکاردیون (collapsed) بعد از render از بین نرود
      const nq = { _uid: q?._uid, title: String(q?.title ?? '').trim(), options: q?.options ?? [], correct: q?.correct ?? -1 };
      if (quizType === 'personality') {
        nq.correct = -1;
        nq.options = (Array.isArray(nq.options) ? nq.options : []).map(o => {
          if (typeof o === 'string') return { label: o, scores: {} };
          return { label: String(o?.label ?? ''), scores: (o?.scores && typeof o.scores === 'object') ? o.scores : {} };
        });
      } else {
        nq.options = (Array.isArray(nq.options) ? nq.options : []).map(o => (typeof o === 'string' ? o : (o?.label ?? '')));
        nq.correct = (quizType === 'normal') ? parseInt(nq.correct ?? 0, 10) : -1;
      }
      return nq;
    });
  };

  const addQuestion = () => {
    if (quizType === 'personality' && (!personalityTypes || personalityTypes.length === 0)) {
      toast('اول Type ها را در تنظیمات MBTI وارد کن و ذخیره کن.');
      return;
    }
    const q = { title: '', options: [], correct: -1 };
    if (quizType === 'personality') {
      q.options = [
        { label: '', scores: {} },
        { label: '', scores: {} },
      ];
      q.correct = -1;
    } else if (quizType === 'poll') {
      q.options = ['', ''];
      q.correct = -1;
    } else {
      q.options = ['', ''];
      q.correct = 0;
    }
    questions.push(q);
    save();
    render();
  };

  const moveQuestion = (idx, dir) => {
    const ni = idx + dir;
    if (ni < 0 || ni >= questions.length) return;
    const tmp = questions[idx];
    questions[idx] = questions[ni];
    questions[ni] = tmp;
    save();
    render();
  };

  const removeQuestion = (idx) => {
    if (!confirm('این سوال حذف شود؟')) return;
    questions.splice(idx, 1);
    save();
    render();
  };

  const addOption = (q) => {
    if (quizType === 'personality') q.options.push({ label: '', scores: {} });
    else q.options.push('');
  };

  const removeOption = (q, oi) => {
    if (q.options.length <= 2) return toast('حداقل باید ۲ گزینه داشته باشی.');
    q.options.splice(oi, 1);
    if (quizType === 'normal') {
      if (q.correct >= q.options.length) q.correct = q.options.length - 1;
    }
  };

  const scoreCell = (q, oi, t) => {
    const current = q.options[oi]?.scores?.[t] ?? 0;
    const inp = el('input', { class: 'ql-control ql-control--mini', type: 'number', value: current, min: '-20', max: '20', step: '1' });
    inp.addEventListener('input', () => {
      const v = parseInt(inp.value || '0', 10);
      q.options[oi].scores = q.options[oi].scores || {};
      q.options[oi].scores[t] = isNaN(v) ? 0 : v;
      save();
    });
    return inp;
  };

  const renderPersonalityScores = (q, oi) => {
    const box = el('div', { class: 'ql-scores' });
    box.appendChild(el('div', { class: 'ql-chip', html: 'امتیازدهی این گزینه' }));
    const grid = el('div', { class: 'ql-scores__grid' });

    personalityTypes.forEach(t => {
      const cell = el('div', { class: 'ql-scores__cell' }, [
        el('span', { class: 'ql-scores__label', html: esc(t) }),
        scoreCell(q, oi, t),
      ]);
      grid.appendChild(cell);
    });

    box.appendChild(grid);
    return box;
  };

  const optionRow = (q, oi, qIndex) => {
    const wrapper = el('div', { class: 'ql-opt-row' });

    if (quizType === 'normal') {
      const radio = el('input', { class: 'ql-radio', type: 'radio', name: `ql_correct_${qIndex}`, value: oi });
      radio.checked = (parseInt(q.correct, 10) === oi);
      radio.addEventListener('change', () => { q.correct = oi; save(); });
      wrapper.appendChild(radio);
    } else {
      wrapper.appendChild(el('span', { class: 'ql-dot', html: '•' }));
    }

    const optVal = quizType === 'personality' ? (q.options[oi]?.label ?? '') : (q.options[oi] ?? '');
    const optInput = el('input', { class: 'ql-control', type: 'text', value: optVal, placeholder: `گزینه ${oi+1}` });
    optInput.addEventListener('input', () => {
      if (quizType === 'personality') q.options[oi].label = optInput.value;
      else q.options[oi] = optInput.value;
      save();
    });

    const delBtn = el('button', { type: 'button', class: 'button button-small' , html: 'حذف' });
    delBtn.addEventListener('click', () => { removeOption(q, oi); save(); render(); });

    wrapper.appendChild(optInput);
    wrapper.appendChild(delBtn);

    return wrapper;
  };

  const questionCard = (q, idx) => {
    const card = el('div', { class: 'ql-q-card' });

    const head = el('div', { class: 'ql-q-head' });
    const uid = ensureUid(q);
    const isCollapsed = collapsed.has(uid);
    const titleNode = el('div', { html: `<b>سوال ${idx+1}</b> ${isCollapsed ? '<span style="color:#667085;font-weight:600;">(بسته)</span>' : ''}` });
    head.appendChild(titleNode);
    head.style.cursor='pointer';

    const headActions = el('div', { class: 'ql-q-head__actions' });
    const toggleBtn = el('button', { type:'button', class:'button button-small', html: isCollapsed ? '＋' : '－' });
    toggleBtn.addEventListener('click', (e)=>{ e.stopPropagation(); if(collapsed.has(uid)) collapsed.delete(uid); else collapsed.add(uid); render(); });
    headActions.appendChild(toggleBtn);
    head.addEventListener('click', (e)=>{ if(e.target && e.target.tagName==='BUTTON') return; if(collapsed.has(uid)) collapsed.delete(uid); else collapsed.add(uid); render(); });
    headActions.appendChild(el('button', { type: 'button', class: 'button button-small', html: '▲', onclick: () => moveQuestion(idx, -1) }));
    headActions.appendChild(el('button', { type: 'button', class: 'button button-small', html: '▼', onclick: () => moveQuestion(idx, +1) }));
    headActions.appendChild(el('button', { type: 'button', class: 'button button-small', html: 'حذف سوال', onclick: () => removeQuestion(idx) }));
    head.appendChild(headActions);

    const titleInput = el('input', { class: 'ql-control', type: 'text', value: q.title || '', placeholder: 'متن سوال را وارد کن…' });
    titleInput.addEventListener('input', () => { q.title = titleInput.value; save(); });

    const optsWrap = el('div', {});
    const renderOptions = () => {
      optsWrap.innerHTML = '';
      q.options.forEach((_, oi) => {
        optsWrap.appendChild(optionRow(q, oi, idx));
        if (quizType === 'personality') {
          optsWrap.appendChild(renderPersonalityScores(q, oi));
        }
      });
    };
    renderOptions();

    const footer = el('div', { class: 'ql-builder__actions', style: 'margin-top:10px' });
    const addOptBtn = el('button', { type: 'button', class: 'button', html: '➕ افزودن گزینه' });
    addOptBtn.addEventListener('click', () => { addOption(q); save(); render(); });

    footer.appendChild(addOptBtn);

    if (quizType === 'normal') {
      footer.appendChild(el('span', { class: 'ql-chip', html: 'گزینه درست را با رادیو انتخاب کن' }));
    } else if (quizType === 'poll') {
      footer.appendChild(el('span', { class: 'ql-chip', html: 'در نظرسنجی پاسخ درست/غلط نداریم' }));
    } else {
      footer.appendChild(el('span', { class: 'ql-chip', html: 'امتیاز هر Type را برای هر گزینه تنظیم کن' }));
    }

    card.appendChild(head);
    const body = el('div', { class: 'ql-q-body', style: isCollapsed ? 'display:none;' : '' });
    body.appendChild(el('div', { style: 'margin:10px 0' }, titleInput));
    body.appendChild(optsWrap);
    body.appendChild(footer);
    card.appendChild(body);
    return card;
  };

  const render = () => {
    normalize();
    save();
    root.innerHTML = '';

    const top = el('div', { class: 'ql-builder__header' });

    const left = el('div', { html: `<span class="ql-chip">سازنده سوالات</span> <span class="ql-chip">نوع: ${quizType === 'personality' ? 'MBTI/شخصیت‌شناسی' : (quizType === 'poll' ? 'نظرسنجی' : 'عادی')}</span>` });
    top.appendChild(left);

    const actions = el('div', { class: 'ql-builder__actions' });
    actions.appendChild(el('button', { type: 'button', class: 'button button-primary', html: '➕ افزودن سوال', onclick: addQuestion }));
    actions.appendChild(el('button', { type: 'button', class: 'button', html: 'پاک کردن همه', onclick: () => {
      if (!confirm('همه سوالات حذف شوند؟')) return;
      questions = []; save(); render();
    }}));
    top.appendChild(actions);

    root.appendChild(top);

    if (quizType === 'personality' && (!personalityTypes || personalityTypes.length === 0)) {
      root.appendChild(el('div', { class: 'ql-empty', html: 'برای ساخت سوالات MBTI، ابتدا «لیست Type ها» را در تنظیمات وارد کن و ذخیره کن.' }));
      return;
    }

    if (!questions.length) {
      root.appendChild(el('div', { class: 'ql-empty', html: 'هنوز سوالی اضافه نشده. روی «افزودن سوال» بزن.' }));
      return;
    }

    questions.forEach((q, i) => root.appendChild(questionCard(q, i)));
  };

  render();
})();

/* --- Personality Types (Tags) + Redirect Selects (AJAX) + Conditional UI --- */
(function(){
  const typeSelect = document.getElementById('ql_type');
  const personalityBox = document.getElementById('ql-personality-settings');
  const questionsBox = document.getElementById('ql-questions-builder');

  const hiddenTypes = document.getElementById('ql_personality_types');
  const typesList = document.getElementById('ql_types_list');
  const typesText = document.getElementById('ql_types_text');
  const typesAdd = document.getElementById('ql_types_add');

  const redirectsContainer = document.getElementById('ql_redirects_container');

  const parse = (raw) => String(raw||'')
    .split(',').map(s=>s.trim()).filter(Boolean)
    .map(s=>s.toUpperCase())
    .filter((v,i,a)=>a.indexOf(v)===i);

  let types = parse(hiddenTypes?.value || typesList?.dataset?.initial || '');

  const getSelectedRedirects = () => {
    try {
      const raw = redirectsContainer?.dataset?.selected || '{}';
      return JSON.parse(raw);
    } catch(e){ return {}; }
  };

  const setSelectedRedirects = (obj) => {
    if (redirectsContainer) redirectsContainer.dataset.selected = JSON.stringify(obj||{});
  };

  const syncHidden = () => {
    if (!hiddenTypes) return;
    hiddenTypes.value = types.join(', ');
    // به سازنده سوالات هم هم‌زمان Types را بده
    if (questionsBox) questionsBox.dataset.types = JSON.stringify(types);
    if (window.QLAdmin && typeof window.QLAdmin.setPersonalityTypes === 'function') {
      window.QLAdmin.setPersonalityTypes(types);
    }
  };

  const renderTags = () => {
    if (!typesList) return;
    typesList.innerHTML = '';
    types.forEach(t=>{
      const chip = document.createElement('span');
      chip.className='ql-tag';
      const palette = ['#E0F2FE','#DCFCE7','#FAE8FF','#FFE4E6','#FFEDD5','#FEF9C3','#EDE9FE','#FCE7F3'];
      chip.style.background = palette[(types.indexOf(t)) % palette.length];
      chip.style.borderColor = 'rgba(17,24,39,.10)';
      chip.innerHTML = `<span>${t}</span>`;
      const x = document.createElement('button');
      x.type='button'; x.textContent='×';
      x.addEventListener('click', ()=>{ types = types.filter(v=>v!==t); syncHidden(); renderTags(); renderRedirects(); });
      chip.appendChild(x);
      typesList.appendChild(chip);
    });
    syncHidden();
  };

  const addType = () => {
    const v = String(typesText?.value||'').trim();
    if (!v) return;
    const up = v.toUpperCase();
    if (!types.includes(up)) types.push(up);
    if (typesText) typesText.value='';
    renderTags();
    renderRedirects();
  };

  if (typesAdd) typesAdd.addEventListener('click', addType);
  if (typesText) typesText.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter') { e.preventDefault(); addType(); }
  });

  const updateVisibility = () => {
    if (!typeSelect) return;
    const t = typeSelect.value;
    if (personalityBox) personalityBox.style.display = (t === 'personality') ? 'block' : 'none';
  };

  let pagesCache = null;
  const fetchPages = async () => {
    if (pagesCache) return pagesCache;
    if (!window.QLAdminCfg) return [];
    const fd = new FormData();
    fd.append('action','ql_pages');
    fd.append('nonce', window.QLAdminCfg.nonce);
    const res = await fetch(window.QLAdminCfg.ajax_url, { method:'POST', body: fd, credentials:'same-origin' });
    const data = await res.json();
    pagesCache = data?.success ? (data.data.pages || []) : [];
    return pagesCache;
  };

  const renderRedirects = async () => {
    if (!redirectsContainer) return;

    // اگر هنوز Type نداریم، باکس راهنما
    if (!types.length) {
      redirectsContainer.className = 'ql-empty';
      redirectsContainer.innerHTML = 'برای ریدایرکت، اول Type ها را اضافه کن.';
      return;
    }

    redirectsContainer.className = 'ql-grid';
    redirectsContainer.style.gridTemplateColumns = 'repeat(3, minmax(0, 1fr))';
    const selectedMap = getSelectedRedirects();

    const pages = await fetchPages();

    redirectsContainer.innerHTML = '';
    types.forEach(t=>{
      const wrap = document.createElement('div');
      wrap.className='ql-field';

      const label = document.createElement('label');
      label.innerHTML = `<b>${t}</b>`;
      wrap.appendChild(label);

      const sel = document.createElement('select');
      sel.className='ql-control';
      sel.name = `ql_redirect_page[${t}]`;

      const opt0 = document.createElement('option');
      opt0.value='';
      opt0.textContent='— بدون ریدایرکت —';
      sel.appendChild(opt0);

      pages.forEach(p=>{
        const o = document.createElement('option');
        o.value = String(p.id);
        o.textContent = p.title || ('#'+p.id);
        sel.appendChild(o);
      });

      const chosen = selectedMap[t] ? String(selectedMap[t]) : '';
      sel.value = chosen;

      sel.addEventListener('change', ()=>{
        const v = sel.value ? parseInt(sel.value,10) : 0;
        const map = getSelectedRedirects();
        if (v>0) map[t]=v; else delete map[t];
        setSelectedRedirects(map);
      });

      wrap.appendChild(sel);
      redirectsContainer.appendChild(wrap);
    });
  };

  // در تغییر نوع آزمون: فقط نمایش تنظیمات
  if (typeSelect) {
    typeSelect.addEventListener('change', () => {
      updateVisibility();
      // برای تغییر نوع: صفحه را ذخیره کن تا سازنده سوالات مطابق نوع جدید رفرش شود
      const hint = document.createElement('div');
      hint.className='ql-empty';
      hint.style.marginTop='10px';
      hint.innerHTML='نوع آزمون تغییر کرد. برای اعمال کامل روی سازنده سوالات، یک‌بار «به‌روزرسانی» بزن.';
      if (questionsBox && !document.getElementById('ql-type-hint')) {
        hint.id='ql-type-hint';
        questionsBox.parentElement?.insertBefore(hint, questionsBox);
      }
    });
  }

  renderTags();
  updateVisibility();
  renderRedirects();
})();
