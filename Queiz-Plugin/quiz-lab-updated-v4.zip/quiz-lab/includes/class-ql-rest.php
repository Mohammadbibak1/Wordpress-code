<?php
if (!defined('ABSPATH')) exit;

class QL_REST {
    public static function routes() {
        register_rest_route('quiz-lab/v1', '/quiz/(?P<id>\d+)', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => [self::class, 'get_quiz'],
        ]);

        register_rest_route('quiz-lab/v1', '/start', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'check_nonce'],
            'callback' => [self::class, 'start_attempt'],
        ]);

        register_rest_route('quiz-lab/v1', '/abandon', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'check_nonce'],
            'callback' => [self::class, 'abandon_attempt'],
        ]);

        register_rest_route('quiz-lab/v1', '/finish', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'check_nonce'],
            'callback' => [self::class, 'finish_quiz'],
        ]);

        register_rest_route('quiz-lab/v1', '/poll-stats/(?P<id>\d+)', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => [self::class, 'poll_stats'],
        ]);
    }

    public static function check_nonce(\WP_REST_Request $req) {
        $nonce = $req->get_header('X-WP-Nonce');
        return (bool) wp_verify_nonce($nonce, 'wp_rest');
    }

    public static function get_quiz(\WP_REST_Request $req) {
        $id = (int) $req['id'];
        $post = get_post($id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }

        $meta = ql_get_quiz_meta($id);

        $safe_questions = [];
        foreach ($meta['questions'] as $q) {
            $opts = [];
            if (isset($q['options']) && is_array($q['options'])) {
                foreach ($q['options'] as $opt) {
                    if (is_array($opt) && isset($opt['label'])) $opts[] = (string)$opt['label'];
                    else $opts[] = (string)$opt;
                }
            }
            $safe_questions[] = [
                'title' => isset($q['title']) ? (string)$q['title'] : '',
                'options' => $opts,
            ];
        }

        return new WP_REST_Response([
            'id' => $id,
            'title' => get_the_title($id),
            'type' => $meta['type'],
            'time_limit' => $meta['time_limit'],
            'login_required' => $meta['login_required'],
            'questions' => $safe_questions,
            'personality_types' => $meta['personality_types'],
        ], 200);
    }

    public static function start_attempt(\WP_REST_Request $req) {
        $quiz_id = (int) $req->get_param('quiz_id');

        $post = get_post($quiz_id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }

        $meta = ql_get_quiz_meta($quiz_id);
        if (!empty($meta['login_required']) && !is_user_logged_in()) {
            return new WP_REST_Response(['message' => 'برای شروع آزمون باید وارد شوید'], 403);
        }

        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';

        $user_id = ql_user_id_or_zero();
        $session_key = $user_id ? '' : ql_get_or_set_guest_session_key();

        $wpdb->insert($attempts, [
            'quiz_id' => $quiz_id,
            'user_id' => $user_id,
            'session_key' => $session_key,
            'status' => 'started',
            'created_at' => ql_now_mysql(),
            'updated_at' => ql_now_mysql(),
        ], ['%d','%d','%s','%s','%s','%s']);

        return new WP_REST_Response(['attempt_id' => (int)$wpdb->insert_id], 200);
    }

    public static function abandon_attempt(\WP_REST_Request $req) {
        $attempt_id = (int) $req->get_param('attempt_id');
        if (!$attempt_id) return new WP_REST_Response(['ok' => true], 200);

        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';

        $wpdb->update($attempts, [
            'status' => 'abandoned',
            'updated_at' => ql_now_mysql(),
        ], ['id' => $attempt_id], ['%s','%s'], ['%d']);

        return new WP_REST_Response(['ok' => true], 200);
    }

    private static function ensure_attempt(int $quiz_id, int $attempt_id): int {
        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';
        if ($attempt_id) return $attempt_id;

        $user_id = ql_user_id_or_zero();
        $session_key = $user_id ? '' : ql_get_or_set_guest_session_key();
        $wpdb->insert($attempts, [
            'quiz_id' => $quiz_id,
            'user_id' => $user_id,
            'session_key' => $session_key,
            'status' => 'started',
            'created_at' => ql_now_mysql(),
            'updated_at' => ql_now_mysql(),
        ], ['%d','%d','%s','%s','%s','%s']);
        return (int)$wpdb->insert_id;
    }

    public static function finish_quiz(\WP_REST_Request $req) {
        $quiz_id = (int) $req->get_param('quiz_id');
        $attempt_id = (int) $req->get_param('attempt_id');
        $answers = (array) $req->get_param('answers');
        $time_spent = (int) $req->get_param('time_spent');

        $post = get_post($quiz_id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }

        $meta = ql_get_quiz_meta($quiz_id);

        if (!empty($meta['login_required']) && !is_user_logged_in()) {
            return new WP_REST_Response(['message' => 'برای شرکت در آزمون باید وارد شوید'], 403);
        }

        $attempt_id = self::ensure_attempt($quiz_id, $attempt_id);

        if ($meta['type'] === 'normal') {
            $graded = QL_Engine::grade_normal($meta['questions'], $answers);
        } elseif ($meta['type'] === 'poll') {
            $graded = QL_Engine::grade_poll($meta['questions'], $answers);
        } elseif ($meta['type'] === 'personality') {
            $graded = QL_Engine::grade_personality($meta['questions'], $answers, $meta['personality_types']);
        } else {
            return new WP_REST_Response(['message' => 'نوع آزمون نامعتبر است'], 400);
        }

        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';
        $ans_tbl  = $wpdb->prefix . 'ql_attempt_answers';

        $wpdb->delete($ans_tbl, ['attempt_id' => $attempt_id], ['%d']);

        foreach (($graded['details'] ?? []) as $d) {
            $wpdb->insert($ans_tbl, [
                'attempt_id' => $attempt_id,
                'question_index' => (int)$d['question_index'],
                'selected_option' => (int)$d['selected'],
                'correct_option' => (int)$d['correct'],
                'is_correct' => (int)$d['is_correct'],
            ], ['%d','%d','%d','%d','%d']);
        }

        $personality_type = '';
        $redirect_url = '';

        if ($meta['type'] === 'normal') {
            $wpdb->update($attempts, [
                'status' => 'finished',
                'score' => $graded['score'],
                'max_score' => $graded['max'],
                'percent' => $graded['percent'],
                'time_spent' => max(0, $time_spent),
                'updated_at' => ql_now_mysql(),
            ], ['id' => $attempt_id], ['%s','%d','%d','%d','%d','%s'], ['%d']);

            return new WP_REST_Response([
                'attempt_id' => $attempt_id,
                'type' => 'normal',
                'score' => $graded['score'],
                'max' => $graded['max'],
                'percent' => $graded['percent'],
            ], 200);
        }

        if ($meta['type'] === 'poll') {
            $wpdb->update($attempts, [
                'status' => 'finished',
                'score' => 0,
                'max_score' => 0,
                'percent' => 0,
                'time_spent' => max(0, $time_spent),
                'updated_at' => ql_now_mysql(),
            ], ['id' => $attempt_id], ['%s','%d','%d','%d','%d','%s'], ['%d']);

            return new WP_REST_Response([
                'attempt_id' => $attempt_id,
                'type' => 'poll',
                'poll_stats' => self::compute_poll_stats($quiz_id, $meta['questions']),
            ], 200);
        }

        // personality
        $personality_type = (string)($graded['personality_type'] ?? '');
        $redir_map = is_array($meta['personality_redirects']) ? $meta['personality_redirects'] : [];
        $target = $redir_map[$personality_type] ?? '';
        $redirect_url = ql_safe_redirect_url($target);

        $wpdb->update($attempts, [
            'status' => 'finished',
            'time_spent' => max(0, $time_spent),
            'personality_type' => $personality_type,
            'redirect_url' => $redirect_url,
            'updated_at' => ql_now_mysql(),
        ], ['id' => $attempt_id], ['%s','%d','%s','%s','%s'], ['%d']);

        return new WP_REST_Response([
            'attempt_id' => $attempt_id,
            'type' => 'personality',
            'personality_type' => $personality_type,
            'totals' => $graded['totals'] ?? [],
            'redirect_url' => $redirect_url,
        ], 200);
    }

    public static function poll_stats(\WP_REST_Request $req) {
        $quiz_id = (int)$req['id'];
        $post = get_post($quiz_id);
        if (!$post || $post->post_type !== 'ql_quiz') {
            return new WP_REST_Response(['message' => 'آزمون پیدا نشد'], 404);
        }
        $meta = ql_get_quiz_meta($quiz_id);
        return new WP_REST_Response(self::compute_poll_stats($quiz_id, $meta['questions']), 200);
    }

    private static function compute_poll_stats(int $quiz_id, array $questions): array {
        global $wpdb;
        $attempts = $wpdb->prefix . 'ql_attempts';
        $ans_tbl  = $wpdb->prefix . 'ql_attempt_answers';

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT a.question_index, a.selected_option, COUNT(*) as cnt
             FROM $ans_tbl a
             JOIN $attempts t ON t.id = a.attempt_id
             WHERE t.quiz_id = %d AND t.status = 'finished'
             GROUP BY a.question_index, a.selected_option",
            $quiz_id
        ), ARRAY_A);

        $counts = [];
        foreach ($rows as $r) {
            $qi = (int)$r['question_index'];
            $oi = (int)$r['selected_option'];
            $cnt = (int)$r['cnt'];
            if (!isset($counts[$qi])) $counts[$qi] = [];
            $counts[$qi][$oi] = $cnt;
        }

        $out = [];
        foreach ($questions as $qi => $q) {
            $labels = [];
            if (isset($q['options']) && is_array($q['options'])) {
                foreach ($q['options'] as $opt) {
                    $labels[] = is_array($opt) && isset($opt['label']) ? (string)$opt['label'] : (string)$opt;
                }
            }
            $total = 0;
            foreach (($counts[$qi] ?? []) as $cnt) $total += (int)$cnt;

            $opts = [];
            foreach ($labels as $oi => $label) {
                $c = (int)(($counts[$qi] ?? [])[$oi] ?? 0);
                $pct = $total > 0 ? (int) round(($c / $total) * 100) : 0;
                $opts[] = ['label' => $label, 'count' => $c, 'percent' => $pct];
            }

            $out[] = [
                'question' => isset($q['title']) ? (string)$q['title'] : '',
                'total' => $total,
                'options' => $opts,
            ];
        }

        return $out;
    }
}
