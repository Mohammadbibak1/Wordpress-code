<?php
if (!defined('ABSPATH')) exit;

class QL_Engine {

    public static function grade_normal(array $questions, array $answers): array {
        $score = 0;
        $max = count($questions);
        $details = [];

        foreach ($questions as $i => $q) {
            $correct = isset($q['correct']) ? (int)$q['correct'] : -1;
            $selected = isset($answers[(string)$i]) ? (int)$answers[(string)$i] : (isset($answers[$i]) ? (int)$answers[$i] : -1);

            $is_correct = ($selected === $correct && $correct >= 0);
            if ($is_correct) $score++;

            $details[] = [
                'question_index' => $i,
                'selected' => $selected,
                'correct' => $correct,
                'is_correct' => $is_correct ? 1 : 0,
            ];
        }

        $percent = $max > 0 ? (int) round(($score / $max) * 100) : 0;

        return [
            'score' => $score,
            'max' => $max,
            'percent' => $percent,
            'details' => $details,
        ];
    }

    public static function grade_poll(array $questions, array $answers): array {
        $details = [];
        foreach ($questions as $i => $q) {
            $selected = isset($answers[(string)$i]) ? (int)$answers[(string)$i] : (isset($answers[$i]) ? (int)$answers[$i] : -1);
            $details[] = [
                'question_index' => $i,
                'selected' => $selected,
                'correct' => -1,
                'is_correct' => 0,
            ];
        }
        return [
            'score' => 0,
            'max' => 0,
            'percent' => 0,
            'details' => $details,
        ];
    }

    public static function grade_personality(array $questions, array $answers, array $types): array {
        $totals = [];
        foreach ($types as $t) $totals[$t] = 0;

        $details = [];

        foreach ($questions as $i => $q) {
            $selected = isset($answers[(string)$i]) ? (int)$answers[(string)$i] : (isset($answers[$i]) ? (int)$answers[$i] : -1);

            $opt_scores = [];
            if ($selected >= 0 && isset($q['options']) && is_array($q['options']) && isset($q['options'][$selected])) {
                $opt = $q['options'][$selected];
                if (is_array($opt) && isset($opt['scores']) && is_array($opt['scores'])) {
                    $opt_scores = $opt['scores'];
                }
            }

            foreach ($opt_scores as $type => $pts) {
                $type = (string)$type;
                if (!array_key_exists($type, $totals)) continue;
                $totals[$type] += (int)$pts;
            }

            $details[] = [
                'question_index' => $i,
                'selected' => $selected,
                'correct' => -1,
                'is_correct' => 0,
            ];
        }

        $winner = '';
        $maxv = null;
        foreach ($totals as $t => $v) {
            if ($maxv === null || $v > $maxv) { $maxv = $v; $winner = $t; }
        }

        arsort($totals);

        return [
            'personality_type' => $winner,
            'totals' => $totals,
            'details' => $details,
        ];
    }
}
