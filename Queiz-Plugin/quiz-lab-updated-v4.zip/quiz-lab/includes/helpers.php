<?php
if (!defined('ABSPATH')) exit;

function ql_sanitize_bool($v): int {
    return !empty($v) ? 1 : 0;
}

function ql_parse_types(string $types_raw): array {
    $types = array_filter(array_map('trim', explode(',', $types_raw)));
    $types = array_values(array_unique($types));
    return $types;
}

function ql_get_quiz_meta(int $quiz_id): array {
    $type = get_post_meta($quiz_id, '_ql_type', true);
    if (!$type) $type = 'normal';

    $time_limit = (int) get_post_meta($quiz_id, '_ql_time_limit', true);
    $login_required = (int) get_post_meta($quiz_id, '_ql_login_required', true);

    $questions = get_post_meta($quiz_id, '_ql_questions', true);
    $questions = is_array($questions) ? $questions : [];

    $types_raw = (string) get_post_meta($quiz_id, '_ql_personality_types', true);
    $types = ql_parse_types($types_raw);

    $redirects = get_post_meta($quiz_id, '_ql_personality_redirects', true);
    $redirects = is_array($redirects) ? $redirects : [];

    return [
        'type' => $type,
        'time_limit' => max(0, $time_limit),
        'login_required' => (int)$login_required,
        'questions' => $questions,
        'personality_types' => $types,
        'personality_redirects' => $redirects,
    ];
}

function ql_user_id_or_zero(): int {
    return is_user_logged_in() ? (int)get_current_user_id() : 0;
}

function ql_get_or_set_guest_session_key(): string {
    if (is_user_logged_in()) return '';
    $key = isset($_COOKIE['ql_guest']) ? sanitize_text_field($_COOKIE['ql_guest']) : '';
    if (!$key || strlen($key) < 10) {
        $key = wp_generate_password(32, false, false);
        setcookie('ql_guest', $key, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN);
        $_COOKIE['ql_guest'] = $key;
    }
    return $key;
}

function ql_now_mysql(): string {
    return current_time('mysql');
}

function ql_safe_redirect_url($value): string {
    if (is_numeric($value)) {
        $url = get_permalink((int)$value);
        return $url ? esc_url_raw($url) : '';
    }
    return $value ? esc_url_raw($value) : '';
}


if (!function_exists('ql_format_seconds')) {
    function ql_format_seconds(int $sec): string {
        $sec = max(0, $sec);
        $m = intdiv($sec, 60);
        $s = $sec % 60;
        return sprintf('%d:%02d', $m, $s);
    }
}
