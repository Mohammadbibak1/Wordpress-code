<?php
if (!defined('ABSPATH')) exit;

class QL_DB {
    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $attempts = $wpdb->prefix . 'ql_attempts';
        $answers  = $wpdb->prefix . 'ql_attempt_answers';

        $sql1 = "CREATE TABLE $attempts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            quiz_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            session_key VARCHAR(64) NOT NULL DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'started',
            score INT NOT NULL DEFAULT 0,
            max_score INT NOT NULL DEFAULT 0,
            percent INT NOT NULL DEFAULT 0,
            time_spent INT NOT NULL DEFAULT 0,
            personality_type VARCHAR(32) NOT NULL DEFAULT '',
            redirect_url TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY quiz_id (quiz_id),
            KEY user_id (user_id),
            KEY session_key (session_key),
            KEY status (status),
            KEY personality_type (personality_type)
        ) $charset_collate;";

        $sql2 = "CREATE TABLE $answers (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            attempt_id BIGINT UNSIGNED NOT NULL,
            question_index INT NOT NULL,
            selected_option INT NOT NULL DEFAULT -1,
            correct_option INT NOT NULL DEFAULT -1,
            is_correct TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY attempt_id (attempt_id)
        ) $charset_collate;";

        dbDelta($sql1);
        dbDelta($sql2);

        update_option('ql_version', QL_VERSION);
    }
}
