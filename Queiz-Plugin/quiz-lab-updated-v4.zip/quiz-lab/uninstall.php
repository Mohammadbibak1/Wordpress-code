<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
// نسخه پایه: داده‌ها را پاک نمی‌کنیم.
